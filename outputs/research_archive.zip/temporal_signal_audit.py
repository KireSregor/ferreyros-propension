"""Test causal daily forecasting and relative long cycles, without final-test use."""

import json
from pathlib import Path
from time import perf_counter

import numpy as np
import optuna
import pandas as pd
from scipy.special import logit
from sklearn.linear_model import Ridge
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits

from audit_6060_round2 import balanced_point, dynamic_features, predict
from ferreyros_propension.data import load_data
from investigate_6060 import operating_points, score_at

OUT = Path("outputs/temporal_signal")


def temporal_features(raw):
    """Forecast aggregate purchase propensity using labels strictly before today.

    Ridge is refitted every 14 days on the preceding 180 days. Lag inputs update
    daily, assuming the prior day's outcomes are available. Relative sine/cosine
    terms do not claim that the dataset contains actual calendar dates.
    """
    events, base = dynamic_features(raw)
    daily = events.groupby("dia_visita").agg(
        purchases=("incidencia_compra", "sum"),
        visits=("id", "size"),
        expected=("tasa_previa", "mean"),
    )
    daily = daily.reindex(range(1, int(events.dia_visita.max()) + 1))
    observed = (daily.purchases + 1) / (daily.visits + 4)
    residual = logit(observed.clip(0.01, 0.99)) - logit(daily.expected.clip(0.01, 0.99))
    lagged = pd.DataFrame({f"lag_{lag}": residual.shift(lag) for lag in range(1, 15)})
    for window in [3, 7, 14, 30]:
        lagged[f"mean_{window}"] = residual.shift().rolling(window).mean()
    forecasts = pd.Series(0.0, index=daily.index)
    for start in range(90, len(daily) + 1, 14):
        train = (daily.index < start) & (daily.index >= start - 180)
        train &= lagged.notna().all(axis=1) & residual.notna()
        valid = (daily.index >= start) & (daily.index < start + 14)
        model = make_pipeline(StandardScaler(), Ridge(alpha=100))
        model.fit(lagged[train], residual[train])
        forecasts.loc[valid] = model.predict(lagged.loc[valid].fillna(0))
    extra = {"forecast_store_logodds": events.dia_visita.map(forecasts)}
    for period in [14, 60, 90, 180, 365]:
        phase = 2 * np.pi * events.dia_visita / period
        extra[f"relative_cycle_{period}_sin"] = np.sin(phase)
        extra[f"relative_cycle_{period}_cos"] = np.cos(phase)
    return (
        events,
        base.drop(columns="cliente_conocido"),
        pd.DataFrame(extra, index=events.index),
    )


def main():
    started = perf_counter()
    OUT.mkdir(exist_ok=True)
    raw = load_data("Dataset/compras_data.csv")
    raw = raw[raw.dia_visita.le(620)].copy()
    events, base, extra = temporal_features(raw)
    _, _, prefix = temporal_features(raw[raw.dia_visita.le(296)])
    pd.testing.assert_frame_equal(
        extra[events.dia_visita.le(296)].reset_index(drop=True), prefix
    )
    changed = raw.copy()
    changed.loc[
        changed.dia_visita.eq(296), ["incidencia_compra", "id_marca", "cantidad"]
    ] = [1, 5, 99]
    _, _, perturbed = temporal_features(changed)
    pd.testing.assert_frame_equal(
        extra[events.dia_visita.le(296)], perturbed[events.dia_visita.le(296)]
    )
    prior = json.loads(Path("outputs/audit_round2/summary.json").read_text())
    spaces = {
        "forecast": pd.concat([base, extra[["forecast_store_logodds"]]], axis=1),
        "cycles": pd.concat(
            [base, extra.drop(columns="forecast_store_logodds")], axis=1
        ),
        "both": pd.concat([base, extra], axis=1),
    }
    records = []

    def evaluate(name, params, space, window):
        frame, _ = predict(
            "lightgbm", params, window, events, spaces[space], [(296, 404), (404, 512)]
        )
        balance, threshold = balanced_point(frame.y, frame.p)
        scores = [
            score_at(part.y, part.p, threshold) for _, part in frame.groupby("fold")
        ]
        stability = min(min(row["precision"], row["recall"]) for row in scores)
        records.append(
            {
                "name": name,
                "space": space,
                "params": params,
                "window": window,
                "stability": stability,
                "balance": balance,
                **score_at(frame.y, frame.p, threshold),
            }
        )
        frame.to_csv(OUT / f"{name}_selection.csv", index=False)
        return stability

    for space in spaces:
        print(
            "CONTROL", space, evaluate(space, prior["params"], space, 270), flush=True
        )
    study = optuna.create_study(
        direction="maximize", sampler=optuna.samplers.TPESampler(seed=202)
    )

    def objective(trial):
        params = {
            "n_estimators": trial.suggest_int("n_estimators", 150, 750, step=100),
            "learning_rate": trial.suggest_float("learning_rate", 0.015, 0.1, log=True),
            "num_leaves": trial.suggest_int("num_leaves", 5, 40),
            "min_child_samples": trial.suggest_int("min_child_samples", 60, 350),
            "reg_lambda": trial.suggest_float("reg_lambda", 1, 100, log=True),
            "colsample_bytree": trial.suggest_float("colsample_bytree", 0.5, 1),
        }
        space = trial.suggest_categorical("space", list(spaces))
        window = trial.suggest_categorical("window", [0, 180, 270])
        value = evaluate(f"trial_{trial.number}", params, space, window)
        print(
            "TRIAL", trial.number, "worst-window min(P,R)", round(value, 4), flush=True
        )
        return value

    study.optimize(objective, n_trials=30)
    study.trials_dataframe().to_csv(OUT / "trials.csv", index=False)
    (OUT / "selection.json").write_text(json.dumps(records, indent=2))
    selected = max(records, key=lambda row: row["stability"])
    frame, diagnostics = predict(
        "lightgbm",
        selected["params"],
        selected["window"],
        events,
        spaces[selected["space"]],
        [(512, 620)],
        True,
    )
    assert len(frame) == 8029 and not frame.duplicated(["id", "dia_visita"]).any()
    frame.to_csv(OUT / "check.csv", index=False)
    summary = {
        "selected": selected,
        "check": score_at(frame.y, frame.p, selected["threshold"]),
        "frontier": operating_points(frame.y, frame.p),
        "train_diagnostics": diagnostics,
        "seconds": perf_counter() - started,
        "causality": "Prefix and current-day perturbation passed. Check513-620 previously inspected; no621+.",
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2))
    print("FINISHED", json.dumps(summary), flush=True)


if __name__ == "__main__":
    optuna.logging.set_verbosity(optuna.logging.WARNING)
    with threadpool_limits(limits=4):
        main()
