"""Temporal nested early stopping and fold-wise generalization-aware search."""

import argparse
import json
from pathlib import Path
from time import perf_counter

import lightgbm as lgb
import numpy as np
import optuna
import pandas as pd
from sklearn.metrics import precision_recall_curve
from threadpoolctl import threadpool_limits

from ferreyros_propension.data import load_data
from ferreyros_propension.feature_research import enriched_features
from refit_lightgbm import operating_point, scores

OUT = Path("outputs/regularized_search")


def fit_fold(events, features, parameters, cut, end):
    """Choose trees on last 54 train days; refit before outer validation."""
    train = events.dia_visita.between(cut - 269, cut)
    inner = events.dia_visita.between(cut - 269, cut - 54)
    stop = events.dia_visita.between(cut - 53, cut)
    valid = events.dia_visita.between(cut + 1, end)
    columns = features.select_dtypes(include=["object", "string"]).columns

    def categorical(train_frame, *other_frames):
        train_frame = train_frame.copy()
        others = [frame.copy() for frame in other_frames]
        for column in columns:
            categories = train_frame[column].unique()
            train_frame[column] = pd.Categorical(
                train_frame[column], categories=categories
            )
            for frame in others:
                frame[column] = pd.Categorical(frame[column], categories=categories)
        return train_frame, *others

    a, b = categorical(features[inner], features[stop])
    model = lgb.LGBMClassifier(
        **parameters, n_estimators=1200, random_state=421, n_jobs=4, verbosity=-1
    )
    model.fit(
        a,
        events.loc[inner, "incidencia_compra"],
        eval_set=[(b, events.loc[stop, "incidencia_compra"])],
        eval_metric="binary_logloss",
        callbacks=[lgb.early_stopping(60, verbose=False)],
    )
    iterations = model.best_iteration_
    a, b = categorical(features[train], features[valid])
    model = lgb.LGBMClassifier(
        **parameters, n_estimators=iterations, random_state=421, n_jobs=4, verbosity=-1
    )
    model.fit(a, events.loc[train, "incidencia_compra"])
    return {
        "cut": cut,
        "end": end,
        "iterations": iterations,
        "train_y": events.loc[train, "incidencia_compra"].to_numpy(),
        "train_p": model.predict_proba(a)[:, 1],
        "val_y": events.loc[valid, "incidencia_compra"].to_numpy(),
        "val_p": model.predict_proba(b)[:, 1],
        "val_id": events.loc[valid, "id"].to_numpy(),
        "val_day": events.loc[valid, "dia_visita"].to_numpy(),
    }


def main(strict=False, precision_focus=False):
    start = perf_counter()
    OUT.mkdir(exist_ok=True)
    raw = load_data("Dataset/compras_data.csv")
    events, features = enriched_features(raw[raw.dia_visita.le(620)])
    features = features.drop(columns="cliente_conocido")
    if strict:
        features = features.drop(
            columns=[
                c
                for c in features
                if c.startswith("fase_")
                or c
                in {
                    "dia_relativo",
                    "antiguedad_observada",
                    "visitas_previas",
                    "compras_previas",
                }
            ]
        )
    study = optuna.create_study(
        direction="maximize", sampler=optuna.samplers.TPESampler(seed=421)
    )
    candidates = []

    def objective(trial):
        parameters = {
            "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.08, log=True),
            "num_leaves": trial.suggest_int("num_leaves", 2, 6)
            if strict
            else trial.suggest_int("num_leaves", 3, 16),
            "max_depth": trial.suggest_int("max_depth", 1, 3)
            if strict
            else trial.suggest_int("max_depth", 2, 5),
            "min_child_samples": trial.suggest_int("min_child_samples", 500, 1800)
            if strict
            else trial.suggest_int("min_child_samples", 200, 900),
            "reg_lambda": trial.suggest_float("reg_lambda", 100, 1500, log=True)
            if strict
            else trial.suggest_float("reg_lambda", 5, 300, log=True),
            "reg_alpha": trial.suggest_float("reg_alpha", 5, 100, log=True)
            if strict
            else trial.suggest_float("reg_alpha", 0.1, 30, log=True),
            "colsample_bytree": trial.suggest_float("colsample_bytree", 0.5, 1.0),
        }
        folds = [
            fit_fold(events, features, parameters, cut, end)
            for cut, end in [(296, 404), (404, 512)]
        ]
        y = np.concatenate([fold["val_y"] for fold in folds])
        p = np.concatenate([fold["val_p"] for fold in folds])
        if precision_focus:
            precision, recall, thresholds = precision_recall_curve(y, p)
            utility = precision[:-1] - 5 * np.maximum(0.0, 0.55 - recall[:-1])
            threshold = float(thresholds[int(np.argmax(utility))])
        else:
            _, threshold = operating_point(y, p)
        metrics = []
        for fold in folds:
            train = scores(fold["train_y"], fold["train_p"], threshold)
            valid = scores(fold["val_y"], fold["val_p"], threshold)
            gap = max(
                0.0,
                train["precision"] - valid["precision"],
                train["recall"] - valid["recall"],
            )
            metrics.append(
                {
                    "cut": fold["cut"],
                    "iterations": fold["iterations"],
                    "train": train,
                    "validation": valid,
                    "max_gap": gap,
                }
            )
        # Explicit trade-off: quality shortfalls, worst fold, and gap above 10pp.
        losses = [
            max(0.0, 0.51 - row["validation"]["precision"])
            + max(0.0, 0.55 - row["validation"]["recall"])
            + (2.0 if strict else 0.5)
            * max(0.0, row["max_gap"] - (0.04 if strict else 0.10))
            for row in metrics
        ]
        utility = min(
            min(row["validation"]["precision"], row["validation"]["recall"])
            for row in metrics
        ) - max(losses)
        if precision_focus:
            utility = min(row["validation"]["precision"] for row in metrics) - max(
                5 * max(0.0, 0.55 - row["validation"]["recall"])
                + max(0.0, row["max_gap"] - 0.04)
                for row in metrics
            )
        record = {
            "trial": trial.number,
            "parameters": parameters,
            "threshold": threshold,
            "folds": metrics,
            "utility": utility,
        }
        candidates.append(record)
        print(
            "trial",
            trial.number,
            "utility",
            round(utility, 4),
            "max gap",
            round(max(row["max_gap"] for row in metrics), 4),
            flush=True,
        )
        return utility

    study.optimize(objective, n_trials=50)
    chosen = max(candidates, key=lambda row: row["utility"])
    check = fit_fold(events, features, chosen["parameters"], 512, 620)
    check_scores = {
        "iterations": check["iterations"],
        "train": scores(check["train_y"], check["train_p"], chosen["threshold"]),
        "validation": scores(check["val_y"], check["val_p"], chosen["threshold"]),
    }
    pd.DataFrame(
        {
            "id": check["val_id"],
            "dia_visita": check["val_day"],
            "y": check["val_y"],
            "p": check["val_p"],
        }
    ).to_csv(OUT / "check.csv", index=False)
    (OUT / "trials.json").write_text(json.dumps(candidates, indent=2))
    summary = {
        "selected": chosen,
        "check": check_scores,
        "seconds": perf_counter() - start,
        "scope": "50 trials, inner early stopping, selection297-512, previously inspected check513-620; no621+.",
        "strict": strict,
        "precision_focus": precision_focus,
        "columns": list(features),
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2))
    print("FINISHED", json.dumps(summary), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--strict", action="store_true")
    parser.add_argument("--precision-focus", action="store_true")
    args = parser.parse_args()
    if args.strict:
        OUT = Path("outputs/regularized_search/strict")
        OUT.mkdir(parents=True, exist_ok=True)
    if args.precision_focus:
        OUT = Path("outputs/regularized_search/precision_focus")
        OUT.mkdir(parents=True, exist_ok=True)
    optuna.logging.set_verbosity(optuna.logging.WARNING)
    with threadpool_limits(limits=4):
        main(args.strict, args.precision_focus)
