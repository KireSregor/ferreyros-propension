"""TabM oficial: parada temporal interna, refit, semillas y mezclas OOF."""

import argparse
import hashlib
import json
import os
from pathlib import Path
from time import perf_counter

os.environ["MLFLOW_DISABLE_AGENT_HINT"] = "1"
import numpy as np
import pandas as pd
import torch
from rtdl_num_embeddings import (
    LinearReLUEmbeddings,
    PiecewiseLinearEmbeddings,
    compute_bins,
)
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OrdinalEncoder, QuantileTransformer
from tabm import TabM

from audit_6060_round2 import balanced_point, dynamic_features
from ferreyros_propension.data import load_data
from investigate_6060 import operating_points, score_at

OUT = Path("outputs/tabm_gpu")
DEVICE = torch.device("cuda")
CONFIGS = {
    "tabm_small": dict(
        width=128, blocks=2, dropout=0.15, k=16, embeddings=False, lr=0.001, decay=0.001
    ),
    "tabm_embeddings": dict(
        width=128, blocks=2, dropout=0.15, k=16, embeddings=True, lr=0.001, decay=0.001
    ),
    "tabm_wide": dict(
        width=256, blocks=3, dropout=0.2, k=32, embeddings=False, lr=0.0005, decay=0.01
    ),
}
MAX_EPOCHS = 1000
PATIENCE = 50
MIN_EPOCHS = 100
BATCH_SIZE = 512


def prepare(train, others):
    """Preprocesadores ajustados exclusivamente con entrenamiento."""
    cats = list(train.select_dtypes(include=["object", "string"]).columns)
    nums = [c for c in train if c not in cats]
    imputer = SimpleImputer(add_indicator=True, keep_empty_features=True)
    numeric = imputer.fit_transform(train[nums])
    scaler = QuantileTransformer(
        n_quantiles=min(1000, len(train)), output_distribution="normal", random_state=42
    )
    numeric = scaler.fit_transform(numeric)
    encoder = OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1)
    category = encoder.fit_transform(train[cats]).astype(np.int64) + 1
    cards = [len(c) + 1 for c in encoder.categories_]

    def tensors(n, c):
        return torch.tensor(n, dtype=torch.float32, device=DEVICE), torch.tensor(
            c, dtype=torch.long, device=DEVICE
        )

    transformed = [tensors(numeric, category)]
    for part in others:
        transformed.append(
            tensors(
                scaler.transform(imputer.transform(part[nums])),
                encoder.transform(part[cats]).astype(np.int64) + 1,
            )
        )
    return transformed, cards


def make_model(config, numeric, cards, seed, training_numeric=None):
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    embedding = LinearReLUEmbeddings(numeric) if config["embeddings"] else None
    if config["embeddings"] == "piecewise":
        # Constant features need a harmless two-edge encoding; their value is zero.
        bins = []
        for column in training_numeric.T:
            if column.min() == column.max():
                bins.append(torch.tensor([-1.0, 1.0], device=DEVICE))
            else:
                bins.extend(compute_bins(column[:, None], n_bins=16))
        embedding = PiecewiseLinearEmbeddings(
            bins, d_embedding=16, activation=True, version="B"
        )
    return TabM.make(
        n_num_features=numeric,
        cat_cardinalities=cards,
        d_out=1,
        n_blocks=config["blocks"],
        d_block=config["width"],
        dropout=config["dropout"],
        k=config["k"],
        num_embeddings=embedding,
    ).to(DEVICE)


@torch.no_grad()
def probabilities(model, x):
    model.eval()
    predictions = []
    for start in range(0, len(x[0]), 1024):
        logits = model(x[0][start : start + 1024], x[1][start : start + 1024]).squeeze(
            -1
        )
        predictions.append(logits.sigmoid().mean(dim=1))
    return torch.cat(predictions)


def train_epoch(model, optimizer, x, y):
    model.train()
    order = torch.randperm(len(y), device=DEVICE)
    total = 0.0
    for ix in order.split(BATCH_SIZE):
        optimizer.zero_grad(set_to_none=True)
        logits = model(x[0][ix], x[1][ix]).squeeze(-1)
        # Official TabM training: average component losses, not loss of averaged scores.
        loss = torch.nn.functional.binary_cross_entropy_with_logits(
            logits, y[ix, None].expand_as(logits)
        )
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        total += float(loss.detach()) * len(ix)
    return total / len(y)


def fit_fold(events, x, cut, end, name, seed, output_dir=None, config=None):
    """Select epoch internally, refit and predict an untouched outer window."""
    output_dir = OUT if output_dir is None else output_dir
    cache = output_dir / f"{name}_s{seed}_cut{cut}.csv"
    if cache.exists():
        return pd.read_csv(cache)
    config = CONFIGS[name] if config is None else config
    start = perf_counter()
    inner = events.dia_visita.le(cut - 54)
    stop = events.dia_visita.between(cut - 53, cut)
    full = events.dia_visita.le(cut)
    valid = events.dia_visita.between(cut + 1, end)
    (a, b), cards = prepare(x[inner], [x[stop]])
    y = torch.tensor(
        events.loc[inner, "incidencia_compra"].to_numpy(),
        dtype=torch.float32,
        device=DEVICE,
    )
    ystop = torch.tensor(
        events.loc[stop, "incidencia_compra"].to_numpy(),
        dtype=torch.float32,
        device=DEVICE,
    )
    model = make_model(config, a[0].shape[1], cards, seed, a[0])
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=config["lr"], weight_decay=config["decay"]
    )
    best_loss = float("inf")
    best_epoch = 0
    history = []
    for epoch in range(1, MAX_EPOCHS + 1):
        training_loss = train_epoch(model, optimizer, a, y)
        p = probabilities(model, b)
        validation_loss = float(torch.nn.functional.binary_cross_entropy(p, ystop))
        if validation_loss < best_loss - 1e-5:
            best_loss, best_epoch = validation_loss, epoch
        history.append(
            {
                "epoch": epoch,
                "train_logloss": training_loss,
                "inner_logloss": validation_loss,
            }
        )
        if epoch % 50 == 0:
            print(
                name,
                seed,
                cut,
                "epoch",
                epoch,
                "best",
                best_epoch,
                round(best_loss, 4),
                flush=True,
            )
        if epoch >= MIN_EPOCHS and epoch - best_epoch >= PATIENCE:
            break
    pd.DataFrame(history).to_csv(
        output_dir / f"{name}_s{seed}_cut{cut}_learning.csv", index=False
    )
    del model, optimizer, a, b, y, ystop
    torch.cuda.empty_cache()
    (a, b), cards = prepare(x[full], [x[valid]])
    y = torch.tensor(
        events.loc[full, "incidencia_compra"].to_numpy(),
        dtype=torch.float32,
        device=DEVICE,
    )
    model = make_model(config, a[0].shape[1], cards, seed, a[0])
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=config["lr"], weight_decay=config["decay"]
    )
    for _ in range(best_epoch):
        train_epoch(model, optimizer, a, y)
    p = probabilities(model, b).cpu().numpy()
    result = events.loc[valid, ["id", "dia_visita", "incidencia_compra"]].rename(
        columns={"incidencia_compra": "y"}
    )
    result["p"] = p
    result.to_csv(cache, index=False)
    metadata = {
        "name": name,
        "seed": seed,
        "cut": cut,
        "inner_stop_start": cut - 53,
        "max_epochs": MAX_EPOCHS,
        "epochs_run": epoch,
        "selected_epoch": best_epoch,
        "inner_logloss": best_loss,
        "seconds": perf_counter() - start,
    }
    (output_dir / f"{name}_s{seed}_cut{cut}.json").write_text(
        json.dumps(metadata, indent=2)
    )
    print("FOLD DONE", json.dumps(metadata), flush=True)
    del model, optimizer, a, b, y
    torch.cuda.empty_cache()
    return result


def main():
    start = perf_counter()
    OUT.mkdir(exist_ok=True)
    if not torch.cuda.is_available():
        raise RuntimeError(
            "No hay GPU PyTorch disponible; revisar instalación antes de ejecutar."
        )
    torch.set_num_threads(4)
    torch.set_float32_matmul_precision("high")
    raw = load_data("Dataset/compras_data.csv")
    events, x = dynamic_features(raw[raw.dia_visita.le(620)])
    x = x.drop(columns=["cliente_conocido"])
    manifest = {
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "feature_code_sha256": hashlib.sha256(
            Path("audit_6060_round2.py").read_bytes()
        ).hexdigest(),
        "data_sha256": hashlib.sha256(
            Path("Dataset/compras_data.csv").read_bytes()
        ).hexdigest(),
        "torch": torch.__version__,
        "gpu": torch.cuda.get_device_name(),
        "configs": CONFIGS,
    }
    path = OUT / "manifest.json"
    if path.exists() and json.loads(path.read_text()) != manifest:
        raise RuntimeError(
            "Cambió versión: usar nueva carpeta para no reutilizar predicciones antiguas."
        )
    path.write_text(json.dumps(manifest, indent=2))
    print("GPU", manifest["gpu"], flush=True)
    records = []
    frames = {}

    def record(name, frame):
        frame = frame.sort_values(["id", "dia_visita"]).reset_index(drop=True)
        frames[name] = frame
        balance, threshold = balanced_point(frame.y, frame.p)
        records.append(
            {
                "candidate": name,
                "balance": balance,
                **score_at(frame.y, frame.p, threshold),
                **operating_points(frame.y, frame.p),
            }
        )
        pd.DataFrame(records).to_csv(OUT / "selection.csv", index=False)
        print("CANDIDATE", name, round(balance, 4), flush=True)

    for name in CONFIGS:
        frame = pd.concat(
            [
                fit_fold(events, x, cut, end, name, 42)
                for cut, end in [(296, 404), (404, 512)]
            ]
        )
        record(name, frame)
    best_arch = max(records, key=lambda r: r["balance"])["candidate"]
    seed_frames = [frames[best_arch]]
    for seed in [17, 73]:
        frame = pd.concat(
            [
                fit_fold(events, x, cut, end, best_arch, seed)
                for cut, end in [(296, 404), (404, 512)]
            ]
        )
        frame = frame.sort_values(["id", "dia_visita"]).reset_index(drop=True)
        pd.testing.assert_frame_equal(
            frame[["id", "dia_visita", "y"]], seed_frames[0][["id", "dia_visita", "y"]]
        )
        seed_frames.append(frame)
    bag = seed_frames[0].copy()
    bag["p"] = np.mean([f.p.to_numpy() for f in seed_frames], axis=0)
    record("seed_bag", bag)
    base = pd.read_csv("outputs/finalists/catboost_oof.csv")
    joins = bag.merge(
        base[["id", "dia_visita", "p"]],
        on=["id", "dia_visita"],
        validate="one_to_one",
        suffixes=("", "_tree"),
    )
    for weight in [0.25, 0.5, 0.75]:
        blend = bag.copy()
        blend["p"] = weight * joins.p + (1 - weight) * joins.p_tree
        record(f"blend_{weight}", blend)
    selected = max(records, key=lambda r: r["balance"])
    chosen = selected["candidate"]
    if chosen in CONFIGS:
        check = fit_fold(events, x, 512, 620, chosen, 42)
    else:
        checks = [
            fit_fold(events, x, 512, 620, best_arch, seed)
            .sort_values(["id", "dia_visita"])
            .reset_index(drop=True)
            for seed in [42, 17, 73]
        ]
        check = checks[0].copy()
        for item in checks[1:]:
            pd.testing.assert_frame_equal(
                check[["id", "dia_visita", "y"]], item[["id", "dia_visita", "y"]]
            )
        check["p"] = np.mean([f.p.to_numpy() for f in checks], axis=0)
        if chosen.startswith("blend_"):
            weight = float(chosen.split("_")[1])
            joined = check.merge(
                base[["id", "dia_visita", "p"]],
                on=["id", "dia_visita"],
                validate="one_to_one",
                suffixes=("", "_tree"),
            )
            check["p"] = weight * joined.p + (1 - weight) * joined.p_tree
    check.to_csv(OUT / "check.csv", index=False)
    summary = {
        "selected": selected,
        "best_architecture": best_arch,
        "check": score_at(check.y, check.p, selected["threshold"]),
        "frontier_diagnostic": operating_points(check.y, check.p),
        "seconds": perf_counter() - start,
        "scope": "Select297-512; previously seen check513-620; inner stopping last54days of train; no621+.",
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2))
    print("FINISHED", json.dumps(summary), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=OUT)
    OUT = parser.parse_args().output_dir
    main()
