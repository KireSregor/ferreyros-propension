"""Compare fixed and fortnightly retraining with strictly earlier labels.

This changes the operating policy: labels must be available before retraining.
Selection uses 297–512; the previously inspected check uses 513–620.
"""

import json
from pathlib import Path
from time import perf_counter

import pandas as pd

from audit_6060_round2 import balanced_point, dynamic_features, predict
from ferreyros_propension.data import load_data
from investigate_6060 import operating_points, score_at


def windows(start, end, step):
    return [(day - 1, min(day + step - 1, end)) for day in range(start, end + 1, step)]


def main():
    started = perf_counter()
    output = Path("outputs/rolling_retraining")
    output.mkdir(exist_ok=True)
    previous = json.loads(Path("outputs/audit_round2/summary.json").read_text())
    raw = load_data("Dataset/compras_data.csv")
    events, features = dynamic_features(raw[raw.dia_visita.le(620)])
    features = features[previous["features"]]
    selection_windows = windows(297, 404, 14) + windows(405, 512, 14)
    records = []
    for history in [90, 180, 270, 0]:
        tick = perf_counter()
        frame, _ = predict(
            "lightgbm", previous["params"], history, events, features, selection_windows
        )
        balance, threshold = balanced_point(frame.y, frame.p)
        record = {
            "history": history,
            "balance": balance,
            **score_at(frame.y, frame.p, threshold),
            "seconds": perf_counter() - tick,
        }
        records.append(record)
        frame.to_csv(output / f"history_{history}_selection.csv", index=False)
        pd.DataFrame(records).to_csv(output / "selection.csv", index=False)
        print(json.dumps(record), flush=True)
    selected = max(records, key=lambda row: row["balance"])
    check, _ = predict(
        "lightgbm",
        previous["params"],
        selected["history"],
        events,
        features,
        windows(513, 620, 14),
    )
    assert len(check) == 8029 and not check.duplicated(["id", "dia_visita"]).any()
    check.to_csv(output / "check.csv", index=False)
    summary = {
        "selected": selected,
        "check": score_at(check.y, check.p, selected["threshold"]),
        "frontier": operating_points(check.y, check.p),
        "seconds": perf_counter() - started,
        "policy": "Refit every 14 days using labels strictly before each scoring window; frozen threshold; no621+.",
    }
    (output / "summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary), flush=True)


if __name__ == "__main__":
    main()
