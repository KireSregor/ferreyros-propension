"""Red tabular MLP y mezclas: selección temporal y umbral congelado."""

import json
from pathlib import Path

import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from threadpoolctl import threadpool_limits

from audit_6060_round2 import balanced_point, dynamic_features
from ferreyros_propension.data import load_data
from investigate_6060 import operating_points, score_at


def main():
    out = Path("outputs/neural_audit")
    out.mkdir(exist_ok=True)
    raw = load_data("Dataset/compras_data.csv")
    events, x = dynamic_features(raw[raw.dia_visita.le(620)])
    x = x.drop(columns=["cliente_conocido"])
    cats = list(x.select_dtypes(include=["object", "string"]).columns)
    numeric = [c for c in x if c not in cats]

    def train(cut, end, layers, alpha):
        a = events.dia_visita.le(cut)
        b = events.dia_visita.between(cut + 1, end)
        prep = ColumnTransformer(
            [
                (
                    "num",
                    make_pipeline(SimpleImputer(add_indicator=True), StandardScaler()),
                    numeric,
                ),
                (
                    "cat",
                    OneHotEncoder(handle_unknown="ignore", sparse_output=False),
                    cats,
                ),
            ]
        )
        model = make_pipeline(
            prep,
            MLPClassifier(
                hidden_layer_sizes=layers,
                alpha=alpha,
                batch_size=256,
                max_iter=70,
                early_stopping=False,
                n_iter_no_change=12,
                random_state=42,
            ),
        )
        model.fit(x[a], events.loc[a, "incidencia_compra"])
        f = events.loc[b, ["id", "dia_visita", "incidencia_compra"]].rename(
            columns={"incidencia_compra": "y"}
        )
        f["p"] = model.predict_proba(x[b])[:, 1]
        return f

    base = pd.read_csv("outputs/finalists/catboost_oof.csv")
    records = []
    settings = {}
    for layers, alpha in [((64, 32), 1.0), ((64, 32), 10.0), ((128, 64, 32), 10.0)]:
        name = f"mlp_{len(layers)}_{alpha}"
        f = pd.concat([train(296, 404, layers, alpha), train(404, 512, layers, alpha)])
        f.to_csv(out / f"{name}_selection.csv", index=False)
        joined = f.merge(
            base[["id", "dia_visita", "p"]],
            on=["id", "dia_visita"],
            validate="one_to_one",
            suffixes=("", "_tree"),
        )
        for weight in [1.0, 0.5, 0.25]:
            p = weight * joined.p + (1 - weight) * joined.p_tree
            balance, threshold = balanced_point(joined.y, p)
            key = f"{name}_weight{weight}"
            records.append(
                {
                    "candidate": key,
                    "balance": balance,
                    "threshold": threshold,
                    **score_at(joined.y, p, threshold),
                    **operating_points(joined.y, p),
                }
            )
            settings[key] = (layers, alpha, weight)
        print(name, max(r["balance"] for r in records), flush=True)
        pd.DataFrame(records).to_csv(out / "selection.csv", index=False)
    best = max(records, key=lambda r: r["balance"])
    layers, alpha, weight = settings[best["candidate"]]
    check = train(512, 620, layers, alpha).merge(
        base[["id", "dia_visita", "p"]],
        on=["id", "dia_visita"],
        validate="one_to_one",
        suffixes=("", "_tree"),
    )
    check["p"] = weight * check.p + (1 - weight) * check.p_tree
    check.to_csv(out / "check.csv", index=False)
    result = {
        "selected": best,
        "check": score_at(check.y, check.p, best["threshold"]),
        "scope": "select297-512; check513-620 previously seen; no621+",
    }
    (out / "summary.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result), flush=True)


if __name__ == "__main__":
    with threadpool_limits(limits=4):
        main()
