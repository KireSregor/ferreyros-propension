"""Diagnóstico y experimentos 60/60 exclusivamente en desarrollo (días <=620)."""

import hashlib
import json
import os
from pathlib import Path
from time import perf_counter

os.environ["MLFLOW_DISABLE_AGENT_HINT"] = "1"
import numpy as np
import optuna
import pandas as pd
import yaml
from catboost import CatBoostClassifier
from lightgbm import LGBMClassifier
from sklearn.metrics import (
    average_precision_score,
    confusion_matrix,
    f1_score,
    log_loss,
    precision_recall_curve,
    precision_score,
    recall_score,
)
from threadpoolctl import threadpool_limits

from ferreyros_propension.data import PRICES, PROMOS, load_data
from ferreyros_propension.feature_research import enriched_features
from ferreyros_propension.modeling import cross_validate

OUT = Path("outputs/research_6060")
FOLDS = [[296, 404], [404, 512], [512, 620]]


def operating_points(y, scores):
    """Exhaustive attainable frontier; same-sample maxima are diagnostic only."""
    precision, recall, thresholds = precision_recall_curve(y, scores)
    precision, recall = precision[:-1], recall[:-1]
    f1 = 2 * precision * recall / np.maximum(precision + recall, 1e-15)
    index = int(np.argmax(f1))
    return {
        "ap": average_precision_score(y, scores),
        "logloss": log_loss(y, np.clip(scores, 1e-7, 1 - 1e-7)),
        "best_f1": f1[index],
        "threshold_f1": float(thresholds[index]),
        "precision_at_best_f1": precision[index],
        "recall_at_best_f1": recall[index],
        "precision_at_recall60": precision[recall >= 0.6].max(initial=0),
        "recall_at_precision60": recall[precision >= 0.6].max(initial=0),
        "feasible_6060": bool(((precision > 0.6) & (recall > 0.6)).any()),
        "balanced_frontier": np.minimum(precision, recall).max(),
    }


def score_at(y, p, threshold):
    labels = np.asarray(p) >= threshold
    tn, fp, fn, tp = confusion_matrix(y, labels, labels=[0, 1]).ravel()
    return {
        "threshold": threshold,
        "precision": precision_score(y, labels, zero_division=0),
        "recall": recall_score(y, labels),
        "f1": f1_score(y, labels),
        "tp": int(tp),
        "fp": int(fp),
        "fn": int(fn),
        "tn": int(tn),
    }


def fit_predict(family, params, x, events, folds):
    """Native categoricals; category vocabularies learned from train only."""
    predictions, train_metrics = [], []
    for number, (cut, end) in enumerate(folds):
        train, valid = (
            events.dia_visita.le(cut),
            events.dia_visita.between(cut + 1, end),
        )
        a, b = x.loc[train].copy(), x.loc[valid].copy()
        categoricals = list(x.select_dtypes(include=["object", "string"]).columns)
        if family == "lightgbm":
            for col in categoricals:
                dtype = pd.CategoricalDtype(categories=a[col].unique())
                a[col], b[col] = a[col].astype(dtype), b[col].astype(dtype)
            model = LGBMClassifier(**params, random_state=42, n_jobs=4, verbosity=-1)
        else:
            model = CatBoostClassifier(
                **params,
                random_seed=42,
                thread_count=4,
                cat_features=categoricals,
                verbose=False,
                allow_writing_files=False,
            )
        model.fit(a, events.loc[train, "incidencia_compra"])
        p = model.predict_proba(b)[:, 1]
        train_p = model.predict_proba(a)[:, 1]
        train_metrics.append(
            {
                "fold": number,
                **operating_points(events.loc[train, "incidencia_compra"], train_p),
            }
        )
        predictions.append(
            pd.DataFrame(
                {
                    "id": events.loc[valid, "id"],
                    "dia_visita": events.loc[valid, "dia_visita"],
                    "y": events.loc[valid, "incidencia_compra"],
                    "p": p,
                    "fold": number,
                }
            )
        )
    return pd.concat(predictions), pd.DataFrame(train_metrics)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    started = perf_counter()
    raw = load_data("Dataset/compras_data.csv")
    raw = raw[raw.dia_visita.le(620)].copy()
    events, x = enriched_features(raw)
    # Engineering invariance, including new lags and purchase intervals.
    early = raw[raw.dia_visita.le(296)]
    _, prefix = enriched_features(early)
    pd.testing.assert_frame_equal(
        x.loc[events.dia_visita.le(296)].reset_index(drop=True), prefix
    )
    changed = early.copy()
    row = changed.index[100]
    changed.loc[row, ["incidencia_compra", "id_marca", "cantidad"]] = [1, 5, 99]
    changed_events, changed_x = enriched_features(changed)
    key = early.loc[row, ["id", "dia_visita"]]
    mask = events.id.eq(key.id) & events.dia_visita.eq(key.dia_visita)
    altered = changed_events.id.eq(key.id) & changed_events.dia_visita.eq(
        key.dia_visita
    )
    pd.testing.assert_series_equal(
        x.loc[mask].iloc[0], changed_x.loc[altered].iloc[0], check_names=False
    )
    initial = events[events.dia_visita.le(296)]
    customers = initial.groupby("id").incidencia_compra.agg(["size", "mean"])
    customers.to_csv(OUT / "customer_train_profile.csv")
    initial.assign(
        compra_anterior=initial.groupby("id").incidencia_compra.shift()
    ).groupby("compra_anterior").incidencia_compra.agg(["size", "mean"]).to_csv(
        OUT / "previous_visit_signal.csv"
    )
    initial.groupby(initial.dia_visita.mod(7)).incidencia_compra.agg(
        ["size", "mean"]
    ).to_csv(OUT / "weekly_phase.csv")
    conditions = (
        initial.groupby("dia_visita")[PRICES + PROMOS].nunique().max().to_dict()
    )
    external = Path(".tmp/research_purchase/data/purchase_data.csv")
    origin_match = None
    if external.exists():
        source = pd.read_csv(external).sort_values(["ID", "Day"]).reset_index(drop=True)
        ours = raw.sort_values(["id", "dia_visita"]).reset_index(drop=True)
        source = source[source.Day.le(620)].reset_index(drop=True)
        origin_match = bool(np.array_equal(source.to_numpy(), ours.to_numpy()))
    audit = {
        "rows_development": len(raw),
        "features": list(x),
        "source_exact_values_match": origin_match,
        "same_day_max_unique_prices_promos": conditions,
        "invariance_checks": "passed",
        "test_loaded_for_fitting_or_scoring": False,
        "data_sha256": hashlib.sha256(
            Path("Dataset/compras_data.csv").read_bytes()
        ).hexdigest(),
    }
    (OUT / "audit.json").write_text(json.dumps(audit, indent=2))
    frames, rows = {}, []

    def register(name, frame, seconds=0):
        frames[name] = frame
        frame.to_csv(OUT / f"{name}_oof.csv", index=False)
        tuning = frame[frame.fold.lt(2)]
        row = {
            "candidate": name,
            "seconds": seconds,
            **operating_points(tuning.y, tuning.p),
        }
        rows.append(row)
        pd.DataFrame(rows).to_csv(OUT / "selection.csv", index=False)
        print(name, json.dumps(row), flush=True)

    base = pd.read_csv("outputs/finalists/catboost_oof.csv")
    register("catboost_original", base)
    reference = base.copy()
    reference["p"] = reference.baseline
    register("baseline_historial", reference)
    config = yaml.safe_load(Path("config.yml").read_text())
    params = json.loads(Path("outputs/best_params.json").read_text())
    # Original features: distinguish a weak family from a weak threshold.
    from ferreyros_propension.data import features

    _, original = features(raw)
    for family in ["logistic", "random_forest", "hist", "xgboost", "lightgbm"]:
        tick = perf_counter()
        _, frame = cross_validate(
            family, params[family], events, original, FOLDS, config
        )
        register(family + "_original", frame, perf_counter() - tick)
    # Ablation separates added historical information from calendar/identity.
    history_x = x.drop(
        columns=[
            "cliente_conocido",
            "dia_relativo",
            "antiguedad_observada",
            "fase_7_sin",
            "fase_7_cos",
            "fase_30_sin",
            "fase_30_cos",
        ]
    )
    best_params = {}
    for label, columns in [
        ("historial_reciente", history_x),
        ("historial_calendario_cliente", x),
    ]:
        study = optuna.create_study(
            direction="maximize",
            sampler=optuna.samplers.TPESampler(seed=42),
            storage="sqlite:///" + (OUT / "optuna.db").as_posix(),
            study_name=label,
            load_if_exists=True,
        )

        def objective(trial):
            candidate = {
                "n_estimators": trial.suggest_int("n_estimators", 150, 600, step=50),
                "learning_rate": trial.suggest_float(
                    "learning_rate", 0.015, 0.12, log=True
                ),
                "num_leaves": trial.suggest_int("num_leaves", 5, 40),
                "min_child_samples": trial.suggest_int("min_child_samples", 40, 250),
                "reg_lambda": trial.suggest_float("reg_lambda", 0.1, 100, log=True),
                "colsample_bytree": trial.suggest_float("colsample_bytree", 0.6, 1),
                "scale_pos_weight": trial.suggest_float(
                    "scale_pos_weight", 0.7, 3, log=True
                ),
            }
            frame, _ = fit_predict("lightgbm", candidate, columns, events, FOLDS[:2])
            trial.set_user_attr("parameters", candidate)
            result = operating_points(frame.y, frame.p)
            trial.set_user_attr("frontier", result)
            # Direct objective: maximize weaker of precision/recall over thresholds.
            return result["balanced_frontier"]

        tick = perf_counter()
        study.optimize(objective, n_trials=max(0, 25 - len(study.trials)))
        candidate = study.best_trial.user_attrs["parameters"]
        best_params[label] = candidate
        frame, train = fit_predict("lightgbm", candidate, columns, events, FOLDS)
        train.to_csv(OUT / f"{label}_train_metrics.csv", index=False)
        register(label, frame, perf_counter() - tick)
        study.trials_dataframe().to_csv(OUT / f"{label}_trials.csv", index=False)
    for weight in [1, 2]:
        tick = perf_counter()
        candidate = {**params["catboost"], "scale_pos_weight": weight}
        frame, train = fit_predict("catboost", candidate, x, events, FOLDS)
        train.to_csv(OUT / f"catboost_enriched_{weight}_train_metrics.csv", index=False)
        register(f"catboost_enriched_{weight}", frame, perf_counter() - tick)
    # Fixed blends, no fitted meta-model; selection still uses only first two folds.
    for name in [
        "historial_reciente",
        "historial_calendario_cliente",
        "catboost_enriched_1",
    ]:
        combined = frames[name].copy()
        combined["p"] = 0.5 * combined.p + 0.5 * base.p.to_numpy()
        register(name + "_blend", combined)
    ranking = pd.DataFrame(rows).sort_values("balanced_frontier", ascending=False)
    winner = ranking.iloc[0].candidate
    evaluations = []
    for name, frame in frames.items():
        tuning, check = frame[frame.fold.lt(2)], frame[frame.fold.eq(2)]
        selection = operating_points(tuning.y, tuning.p)
        threshold = selection["threshold_f1"]
        evaluations.append(
            {
                "candidate": name,
                "selected_before_check": name == winner,
                **score_at(check.y, check.p, threshold),
                **{
                    f"diagnostic_{k}": v
                    for k, v in operating_points(check.y, check.p).items()
                },
            }
        )
    pd.DataFrame(evaluations).to_csv(OUT / "chronological_check.csv", index=False)
    frozen = frames[winner]
    threshold = operating_points(
        frozen[frozen.fold.lt(2)].y, frozen[frozen.fold.lt(2)].p
    )["threshold_f1"]
    report = {
        "winner_selected_first_two_folds": winner,
        "threshold_selected_first_two_folds": threshold,
        "winner_selection": ranking.iloc[0].to_dict(),
        "chronological_check": next(
            row for row in evaluations if row["candidate"] == winner
        ),
        "seconds": perf_counter() - started,
        "claim": "No theoretical impossibility claim; empirical finite search only.",
        "protocol": "Train <=296; search/threshold on OOF297-512; check513-620, previously seen; no test621-730.",
        "parameters": best_params,
    }
    (OUT / "summary.json").write_text(json.dumps(report, indent=2))
    print("FINISHED", json.dumps(report), flush=True)


if __name__ == "__main__":
    optuna.logging.set_verbosity(optuna.logging.WARNING)
    with threadpool_limits(limits=4):
        main()
