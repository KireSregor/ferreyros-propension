"""Controlled monthly-trend ablation, keeping model and threshold policy fixed."""

import json
from pathlib import Path
from time import perf_counter

import pandas as pd
from threadpoolctl import threadpool_limits

from ferreyros_propension.data import load_data
from ferreyros_propension.feature_research import monthly_trend_features
from refit_lightgbm import operating_point, predict, scores


def main():
    started = perf_counter()
    output = Path("outputs/refit_lightgbm")
    raw = load_data("Dataset/compras_data.csv")
    raw = raw[raw.dia_visita.le(620)].copy()
    events, features = monthly_trend_features(raw)
    _, prefix = monthly_trend_features(raw[raw.dia_visita.le(296)])
    pd.testing.assert_frame_equal(
        features[events.dia_visita.le(296)].reset_index(drop=True), prefix
    )
    altered = raw.copy()
    altered.loc[
        altered.dia_visita.eq(296), ["incidencia_compra", "id_marca", "cantidad"]
    ] = [1, 5, 99]
    _, changed = monthly_trend_features(altered)
    pd.testing.assert_frame_equal(
        features[events.dia_visita.le(296)], changed[events.dia_visita.le(296)]
    )
    features = features.drop(columns="cliente_conocido")
    params = json.loads((output / "summary.json").read_text())["selected"]
    spaces = {
        "control": [c for c in features if not c.startswith("month_")],
        "add_monthly": list(features),
        "recent_without_lifetime": [
            c
            for c in features
            if c
            not in {
                "tasa_previa",
                "visitas_previas",
                "compras_previas",
                "dia_relativo",
                "antiguedad_observada",
            }
            and not c.startswith("fase_")
        ],
    }
    records = []
    candidates = {}
    for name, columns in spaces.items():
        frame = predict(
            events,
            features[columns],
            params["params"],
            [(296, 404), (404, 512)],
            params["window"],
        )
        utility, threshold = operating_point(frame.y, frame.p)
        records.append(
            {
                "name": name,
                "utility": utility,
                "columns": columns,
                **scores(frame.y, frame.p.to_numpy(), threshold),
            }
        )
        candidates[name] = columns
        print(name, records[-1]["precision"], records[-1]["recall"], flush=True)
    # One candidate selected before checking the later period.
    chosen = max(records, key=lambda row: row["utility"])
    check = predict(
        events,
        features[candidates[chosen["name"]]],
        params["params"],
        [(512, 620)],
        params["window"],
    )
    check.to_csv(output / "monthly_check.csv", index=False)
    result = {
        "selection": records,
        "selected": chosen["name"],
        "check": scores(check.y, check.p.to_numpy(), chosen["threshold"]),
        "seconds": perf_counter() - started,
        "invariance_checks": "prefix and current-day outcomes passed",
        "scope": "Select297-512; previously inspected check513-620; no621+.",
    }
    (output / "monthly_trends.json").write_text(json.dumps(result, indent=2))
    print("FINISHED", result["selected"], result["check"], flush=True)


if __name__ == "__main__":
    with threadpool_limits(limits=4):
        main()
