"""Test personal response histories with causal features and temporal selection."""

import json
from pathlib import Path
from time import perf_counter

import numpy as np
import optuna
import pandas as pd
from threadpoolctl import threadpool_limits

from audit_6060_round2 import balanced_point, dynamic_features, predict
from ferreyros_propension.data import load_data
from investigate_6060 import operating_points, score_at

OUT = Path("outputs/conditional_history")


def conditional_features(raw):
    """Response rates count only earlier visits of the same customer and context."""
    events, features = dynamic_features(raw)
    extra = {}
    groups = events.groupby("id", sort=False)
    contexts = {
        "previous_purchase": groups.incidencia_compra.shift().fillna(-1),
        "previous_brand": groups.id_marca.shift().fillna(-1),
        "any_promotion": events[[f"promo_marca_{i}" for i in range(1, 6)]].max(axis=1),
        "visit_gap": pd.cut(
            groups.dia_visita.diff(), [-1, 3, 7, 14, 30, np.inf]
        ).astype(str),
    }
    for brand in range(1, 6):
        price = events[f"precio_marca_{brand}"]
        average = price.groupby(events.id).transform(
            lambda values: values.expanding().mean().shift()
        )
        extra[f"personal_price_ratio_{brand}"] = price / average
        contexts[f"promotion_{brand}"] = events[f"promo_marca_{brand}"]
        contexts[f"cheap_{brand}"] = (price < average).astype(int)
    for name, context in contexts.items():
        grouping = [events.id, context]
        count = events.groupby(grouping).cumcount()
        purchases = (
            events.incidencia_compra.groupby(grouping).cumsum()
            - events.incidencia_compra
        )
        extra[f"context_support_{name}"] = count
        for prior in [5, 20]:
            extra[f"context_rate_{name}_{prior}"] = (
                purchases + prior * events.tasa_previa
            ) / (count + prior)
    combined = pd.concat([features, pd.DataFrame(extra, index=events.index)], axis=1)
    return events, combined.drop(columns="cliente_conocido")


def main():
    started = perf_counter()
    OUT.mkdir(exist_ok=True)
    raw = load_data("Dataset/compras_data.csv")
    raw = raw[raw.dia_visita.le(620)].copy()
    events, features = conditional_features(raw)
    _, prefix = conditional_features(raw[raw.dia_visita.le(296)])
    pd.testing.assert_frame_equal(
        features[events.dia_visita.le(296)].reset_index(drop=True), prefix
    )
    altered = raw.copy()
    altered.loc[
        altered.dia_visita.eq(296), ["incidencia_compra", "id_marca", "cantidad"]
    ] = [1, 5, 99]
    _, changed = conditional_features(altered)
    pd.testing.assert_frame_equal(
        features[events.dia_visita.le(296)], changed[events.dia_visita.le(296)]
    )
    prior = json.loads(Path("outputs/audit_round2/summary.json").read_text())
    records = []

    def evaluate(name, params, window):
        frame, _ = predict(
            "lightgbm", params, window, events, features, [(296, 404), (404, 512)]
        )
        balance, threshold = balanced_point(frame.y, frame.p)
        scores = [
            score_at(part.y, part.p, threshold) for _, part in frame.groupby("fold")
        ]
        stability = min(min(score["precision"], score["recall"]) for score in scores)
        records.append(
            {
                "name": name,
                "params": params,
                "window": window,
                "balance": balance,
                "stability": stability,
                **score_at(frame.y, frame.p, threshold),
            }
        )
        frame.to_csv(OUT / f"{name}_selection.csv", index=False)
        return stability

    evaluate("same_parameters", prior["params"], 270)
    study = optuna.create_study(
        direction="maximize", sampler=optuna.samplers.TPESampler(seed=128)
    )

    def objective(trial):
        params = {
            "n_estimators": trial.suggest_int("n_estimators", 150, 650, step=100),
            "learning_rate": trial.suggest_float(
                "learning_rate", 0.015, 0.08, log=True
            ),
            "num_leaves": trial.suggest_int("num_leaves", 5, 40),
            "min_child_samples": trial.suggest_int("min_child_samples", 80, 400),
            "reg_lambda": trial.suggest_float("reg_lambda", 1, 100, log=True),
            "reg_alpha": trial.suggest_float("reg_alpha", 0.01, 10, log=True),
            "colsample_bytree": trial.suggest_float("colsample_bytree", 0.5, 1),
        }
        window = trial.suggest_categorical("window", [0, 180, 270])
        value = evaluate(f"trial_{trial.number}", params, window)
        print(
            "trial", trial.number, "worst-window min(P,R)", round(value, 4), flush=True
        )
        return value

    study.optimize(objective, n_trials=30)
    study.trials_dataframe().to_csv(OUT / "trials.csv", index=False)
    (OUT / "selection.json").write_text(json.dumps(records, indent=2))
    selected = max(records, key=lambda row: row["stability"])
    frame, diagnostics = predict(
        "lightgbm",
        selected["params"],
        selected["window"],
        events,
        features,
        [(512, 620)],
        True,
    )
    frame.to_csv(OUT / "check.csv", index=False)
    summary = {
        "selected": selected,
        "check": score_at(frame.y, frame.p, selected["threshold"]),
        "frontier": operating_points(frame.y, frame.p),
        "train_diagnostics": diagnostics,
        "features": list(features),
        "seconds": perf_counter() - started,
        "causality": "Prefix and current-day perturbation passed; check513-620 previously inspected; no621+.",
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2))
    print("FINISHED", json.dumps(summary["check"]), flush=True)


if __name__ == "__main__":
    optuna.logging.set_verbosity(optuna.logging.WARNING)
    with threadpool_limits(limits=4):
        main()
