# Diagnóstico del objetivo de precisión y recall >60 %

## Conclusión

El candidato seleccionado en días 297–512 es `historial_calendario_cliente_blend`. Con un umbral balanceado de 0.3587, fijado antes de la comprobación, obtiene en días 513–620 precisión **50.4%**, recall **54.9%** y F1 **0.526**. Cumple 60/60: **False**.

Esto es evidencia de que los candidatos y variables probados no alcanzan el requisito, NO una demostración matemática de que ningún modelo pueda alcanzarlo. No se vuelve a consultar ni puntuar días 621–730. Las ventanas de desarrollo ya se habían usado históricamente; la comprobación temporal no es una muestra externa virgen.

## Datos e hipótesis

- EDA adicional limitado a días 1–296; 500 clientes, observaciones repetidas por visita.
- Coincidencia exacta de valores y orden de columnas renombradas con la base pública de k-bosko (solo se contrasta hasta día 620). Su README atribuye la base al curso Customer Analytics; no proporciona un techo predictivo ni prueba un mecanismo generador.
- Después de una visita con compra, conversión observada 40,3 %; después de una sin compra, 18,9 %. Asociación, no causalidad ni garantía de predictibilidad.
- Dentro de un día, todos reciben los mismos precios y promociones; las filas no son miles de experimentos comerciales independientes.
- Nuevas hipótesis: lags 1/2/3; últimas 3/5/10/20 visitas; medias exponenciales; ventanas 7/14 días; cadencia individual de visita/compra; recencia relativa; cantidad previa; precio/promoción ponderados por preferencias históricas; antigüedad y fases relativas 7/30; categoría cliente conocido.
- Identidad se probó como categoría, sin usar el código numérico como señal ordenada. No se incluyó tamaño de ciudad (excluido por diccionario), marca/cantidad actuales ni conversiones del día completo.
- Invariancia ante futuro y resultado actual comprobada en la ejecución. El historial se actualiza después de cada resultado observado, según el escenario secuencial ya definido.

## Pruebas

- Seis familias originales, comparación de todos sus umbrales.
- Dos espacios de LightGBM, 25 pruebas Optuna cada uno, dos folds por prueba; objetivo directo: máximo de la menor de precisión y recall al recorrer umbrales.
- CatBoost con variables enriquecidas y dos pesos de clase; tres mezclas simples 50/50.
- Selección de candidato solo en OOF297–512. Primera evaluación de cada familia usa parámetros previamente seleccionados en desarrollo: existe optimismo heredado de selección, declarado.
- Umbral balanceado seleccionado en 297–512; se congela para 513–620. Se conserva también la alternativa que maximiza F1; no se selecciona por el resultado posterior.
- Los máximos obtenidos recorriendo umbrales sobre el mismo conjunto son diagnósticos optimistas, no estimaciones de despliegue. Su utilidad: si ni siquiera allí aparece 60/60, un cambio de umbral de ese ranking no puede producirlo en esa muestra.
- Bootstrap emparejado por cliente: intervalos para modelo y umbral fijos. No incluye incertidumbre de selección ni todo el cambio temporal.

## Qué indican los límites observados

En las dos primeras ventanas, ningún candidato alcanza 60/60: **True**. La mejor menor-métrica es 53.7%, frente al 60 % solicitado. El conjunto de curvas muestra el compromiso real: al capturar compras menos evidentes se incorporan también no-compras.

El entrenamiento y la validación se conservan en `*_train_metrics.csv`: si entrenar memoriza más compras y no mejora validación, aumentar capacidad no basta. No confundimos esta observación con un límite teórico de la base. Ningún resultado autoriza prometer que solo más Optuna logrará el objetivo.

Posibles avances requieren hipótesis nuevas y evaluación temporal: información previa sobre intención de compra, inventario del hogar, necesidad del producto o contexto de visita, si el negocio puede capturarla. No existe evidencia aquí para prometer cuánto mejoraría. Ampliar la búsqueda con otra familia o representación sigue siendo posible; esta investigación es finita.

## Archivos y reproducción

`python investigate_6060.py` ejecuta auditoría, variables, búsqueda y comparación. `python consolidate_6060.py` construye esta síntesis y actualiza el notebook. Duración de investigación: 3.02 minutos; consolidación no incluida. Resultados completos en CSV/JSON; Optuna en SQLite (no publicar la base por defecto).

Fuentes: [repositorio original contrastado](https://github.com/k-bosko/purchase_prediction), [umbral y riesgo de sobreajuste](https://scikit-learn.org/stable/modules/classification_threshold.html).
