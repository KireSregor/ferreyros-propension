# TPE iniciado en la ganadora de Grid

60 pruebas, mismas variables, folds, semilla del modelo, límite de árboles, parada interna y objetivo de selección que Grid. La primera prueba fija la ganadora anterior; las restantes exploran tasas de aprendizaje 0,005–0,05, profundidad 1–3, mínimo de observaciones por hoja 250–1000, L2 30–1000, L1 5–150 y vida media 30–365 días. El espacio difiere de la rejilla, por lo que no es un benchmark puro entre samplers.

| Fold | Días train / val | Precisión train → val | Recall train → val |
|---|---|---|---|
| 1 | 27–296 / 297–404 | 48,9% → 52,2% | 50,7% → 51,8% |
| 2 | 135–404 / 405–512 | 50,4% → 54,3% | 52,6% → 54,7% |
| 3 | 243–512 / 513–620 | 52,9% → 49,1% | 54,9% → 55,6% |

La puntuación de selección mejoró de 0,5122 a 0,5184. En la comprobación posterior, Grid había obtenido precisión 49,34% y recall 55,78%; TPE obtuvo 49,09% y 55,64%. La mejora en selección no se sostuvo después. No se promueve el candidato.

Umbral 0,283338 elegido con folds 1–2. Ganador: profundidad 1, dos hojas, mínimo 827 observaciones por hoja, tasa de aprendizaje 0,01301, L2 757,35, L1 6,46 y vida media 137,82 días. Los tres ajustes internos alcanzaron 1.000 árboles. Duración: 173 segundos. Total: 242 entrenamientos (60×2×2 + 2).

513–620 ya fue inspeccionado reiteradamente; no es confirmación independiente. No se evaluaron días 621–730. No se garantiza ausencia de sobreajuste. Reproducción: `python final_balance_search.py --warm-tpe`.
