# Búsqueda para reducir el sobreajuste

Se probaron 50 configuraciones LightGBM con menor complejidad, regularización y parada anticipada. En cada fold, los últimos 54 días del entrenamiento eligen el número de árboles mediante log loss; después se reajusta con todo el entrenamiento del fold y se valida en el periodo posterior.

Optuna penaliza explícitamente incumplimientos de precisión 51%, recall 55%, una brecha train–validación superior a 10 puntos y el desempeño del peor de los dos folds de selección. Los 10 puntos son una regla de búsqueda, no una garantía de generalización. El umbral común se elige con las predicciones combinadas de los dos folds: puede favorecer su promedio y no garantiza que cada uno cumpla. Esas validaciones también fueron utilizadas en investigaciones previas.

| Fold | Entrenamiento | Validación | Precisión train → val | Recall train → val |
|---|---|---|---|---|
| 1 | 27–296 | 297–404 | 54,3% → 52,8% | 59,5% → 52,7% |
| 2 | 135–404 | 405–512 | 55,1% → 50,2% | 57,5% → 57,9% |
| 3 | 243–512 | 513–620 | 56,4% → 49,4% | 59,9% → 55,5% |

En el fold 3, el candidato anterior registró 60,2% → 47,4% de precisión y 73,3% → 57,8% de recall. La brecha de ambos se redujo; la precisión de validación mejoró 1,9 puntos, mientras el recall cayó 2,3 puntos. Los modelos y umbrales son diferentes, por lo que no se atribuye todo el efecto únicamente a la regularización.

El baseline histórico, con umbral elegido en los mismos folds de selección, obtuvo en 513–620 precisión 48,2% y recall 48,5%. El candidato obtuvo 49,4% y 55,5%, respectivamente. No alcanza precisión >51%, y el primer fold tampoco alcanza recall 55%. No se declara ausencia de sobreajuste ni se sustituye el modelo guardado.

El periodo 513–620 ya se había inspeccionado reiteradamente; no es test independiente. Los días 621–730 no se evaluaron en esta búsqueda. Resultados, parámetros e iteraciones están en `summary.json`, `folds.csv` y `trials.json`; código `regularized_search.py`. Duración aproximada: 59 segundos.
