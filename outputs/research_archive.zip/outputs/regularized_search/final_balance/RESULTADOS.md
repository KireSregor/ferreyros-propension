# Última ronda: adaptación temporal y equilibrio de precisión/recall

Objetivo fijado antes de ejecutar: precisión y recall >51% simultáneamente, con umbral elegido en 297–512. Se probaron 40 configuraciones nuevas.

## Fundamento y cambios

La revisión [Learning under nonstationarity](https://wires.onlinelibrary.wiley.com/doi/10.1002/wics.1275) distingue cambios de distribución de variables de cambios en la relación con el resultado y describe ponderación de observaciones. Eso no garantiza que ponderar por recencia corrija esta base. Se probó como hipótesis, sin afirmar equivalencia con un estimador de importancia entre dominios.

Se incorporaron precios divididos por la mediana de los 60 días anteriores, evitando depender solo de niveles absolutos; tendencias personales en bloques disjuntos de 30 días; peso exponencial según antigüedad de cada observación (vidas medias 45/90/180 días o prácticamente uniforme); árboles limitados y regularizados; parada anticipada usando los últimos 45 días de entrenamiento. Después se reajustó en el entrenamiento completo del fold durante la cantidad seleccionada de árboles.

Se revisó también [EBM, documentación oficial](https://interpret.ml/docs/ebm.html) y el trabajo [Drift-Resilient TabPFN](https://proceedings.neurips.cc/paper_files/paper/2024/file/b2e2774c8e76afe191b5bf518f5cb727-Paper-Conference.pdf). No se implementaron esos modelos ni se atribuyen sus resultados a este experimento.

## Resultado

| Fold | Precisión train → val | Recall train → val |
|---|---|---|
| 1: 27–296 / 297–404 | 50,4% → 53,5% | 52,9% → 50,0% |
| 2: 135–404 / 405–512 | 50,5% → 53,6% | 54,7% → 57,4% |
| 3: 243–512 / 513–620 | 52,9% → 49,9% | 57,9% → 54,6% |

No se cumple el criterio. La brecha del fold 3 es de 3,0 puntos en precisión y 3,3 en recall; la reducción de memorización no produce por sí misma suficiente discriminación. La configuración elegida usa vida media 90 días y 180 árboles en el último fold, seleccionados internamente. Duración: 51 segundos.

El objetivo de Optuna considera el peor fold y penaliza una brecha positiva superior a cinco puntos; el umbral común maximiza la menor precisión/recall combinadas en los folds de selección. La regla no garantiza que cada fold cumpla el mínimo, como muestra el recall del primero.

El periodo 513–620 ya fue inspeccionado repetidamente. Es una comprobación exploratoria, no un test independiente. No se evaluó 621–730. No se promueve este candidato al modelo principal. No se declara que 51/51 sea imposible para todos los métodos posibles.

Reproducción: `python final_balance_search.py`. Parámetros, umbral, predicciones y todas las configuraciones en esta carpeta. No se ajustó el umbral mirando las etiquetas posteriores.
