# Por qué la precisión parece igual al baseline

La comparación anterior usaba puntos operativos distintos: baseline 48,2% precisión y 48,5% recall; modelo estricto 48,6% precisión y 58,8% recall. El modelo detecta más compras y, al hacerlo, admite casos menos evidentes. Por ello esa tabla no mide precisión a igual recall.

Sobre las mismas 8.029 visitas de 513–620, recorrer la curva PR da estas fronteras diagnósticas:

| Recall mínimo | Precisión máxima histórica | Precisión máxima modelo estricto |
|---|---:|---:|
| 50% | 47,2% | 52,4% |
| 55% | 45,7% | 49,9% |
| 58% | 44,4% | 48,8% |
| 60% | 43,9% | 47,7% |

Estos máximos usan las etiquetas del mismo periodo; no son umbrales elegidos previamente ni métricas confirmadas de despliegue. Sí permiten diagnosticar que el ranking del modelo mejora al baseline: AP 0,555 frente a 0,528; AUC 0,749 frente a 0,707. Correlación Spearman entre scores: 0,798, compatible con dependencia compartida del historial, sin probar causalidad.

La investigación previa por grupos de variables aporta evidencia complementaria. En `outputs/tables/history_diagnostic.csv`, para el último fold, solo historial obtiene AP 0,562 y el modelo completo 0,565: demografía y condiciones comerciales añaden poco en esa comparación concreta. No son los mismos parámetros del candidato estricto, por lo que no deben restarse sus métricas como efecto causal universal. En la ablación original, quitar historial reduce AP media a 0,458, mucho más que quitar demografía (0,576) o comercial (0,574).

Conclusión: no estamos ante ausencia total de mejora. El historial ya resume gran parte de la señal disponible y las variables adicionales aportan poco en los experimentos realizados. Además, la precisión semejante se comparó a recalls diferentes. El modelo estricto ordena mejor y consigue unos cuatro puntos adicionales de precisión a recall alrededor de 55–58% en esta frontera diagnóstica; aun así no cumple el objetivo de precisión >51% conservando ese recall con un umbral validado previamente.

No se ha demostrado un techo teórico de esta base. El periodo fue inspeccionado repetidamente; hace falta una evaluación independiente antes de confirmar una mejora final.
