# Búsqueda exhaustiva completada

Se recorrieron 216 combinaciones distintas: tasa de aprendizaje {0,015; 0,035; 0,07}, profundidad {1; 2; 3}, mínimo de observaciones por hoja {200; 500; 900}, regularización L2 {10; 300}, L1 {1; 50} y vida media temporal {90; 10000 días}. Las hojas se fijan a 2 elevado a profundidad. El número de árboles se selecciona mediante parada interna con máximo 1.000.

Cada combinación se evaluó en dos folds con ajuste interno y reajuste: 864 entrenamientos, más dos para la comprobación posterior. Duración: 461 segundos (7 min 41 s). La búsqueda es exhaustiva únicamente respecto a esta rejilla, no un óptimo global sobre todos los modelos o hiperparámetros posibles.

## Resultado del candidato elegido

| Fold | Entrenamiento | Validación | Precisión train → val | Recall train → val |
|---|---|---|---|---|
| 1 | 27–296 | 297–404 | 49,6% → 52,0% | 50,0% → 51,2% |
| 2 | 135–404 | 405–512 | 50,1% → 53,9% | 52,6% → 54,8% |
| 3 | 243–512 | 513–620 | 53,0% → 49,3% | 55,0% → 55,8% |

Selección por peor fold, penalizando brechas mayores de cinco puntos. Umbral común 0,283770 elegido con validaciones 297–512 y congelado antes de comprobar 513–620. La configuración elegida es profundidad 1, dos hojas, mínimo 500 observaciones por hoja, L2 300, L1 50 y vida media 90 días. Llegó a 999/1000/1000 árboles: la parada no actuó antes del máximo en los dos últimos ajustes internos.

Ambas métricas superaron 51% en los folds de selección, pero no en la comprobación posterior. La brecha de precisión posterior es 3,7 puntos y el recall no cae. No se cumple el requisito de precisión y recall >51% en el periodo posterior.

El baseline con su propio umbral seleccionado previamente obtuvo en ese periodo precisión 48,2% y recall 48,5%. El incremento de precisión del candidato es aproximadamente 1,2 puntos; no se ha establecido su significación estadística. No se promueve el candidato ni se certifica ausencia de sobreajuste.

El periodo 513–620 ya fue inspeccionado repetidamente: este resultado es exploratorio y no una confirmación independiente. No se evaluó 621–730. La ampliación de la búsqueda no eliminó el deterioro temporal y no prueba imposibilidad para todo método posible.

Reproducción: `python final_balance_search.py --grid`. Configuración, rejilla, métricas y tiempo en `summary.json`; todas las combinaciones en `trials.json`; predicciones posteriores en `check.csv`.
