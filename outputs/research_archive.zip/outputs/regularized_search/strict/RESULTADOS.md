# Regularización estricta

50 configuraciones, árboles de profundidad 1–3 y 2–6 hojas, mínimo de 500–1.800 observaciones por hoja y regularización aumentada. Se retiraron fases artificiales, día relativo, antigüedad y conteos acumulados. Penalización de brechas superiores a cuatro puntos en folds de selección. Son decisiones de búsqueda, no garantías estadísticas.

| Fold | Precisión train → val | Recall train → val |
|---|---|---|
| 1: 27–296 / 297–404 | 46,5% → 51,1% | 55,6% → 54,9% |
| 2: 135–404 / 405–512 | 49,4% → 51,8% | 56,3% → 57,9% |
| 3: 243–512 / 513–620 | 51,0% → 48,6% | 57,9% → 58,8% |

La brecha positiva de precisión del fold 3 bajó a 2,4 puntos. El recall posterior supera ligeramente al de entrenamiento. Esto reduce la señal de memorización que veíamos; no demuestra ausencia absoluta de sobreajuste ni elimina el cambio temporal.

Respecto a la regularización anterior, la precisión posterior baja de 49,4% a 48,6%, el recall sube de 55,5% a 58,8% y F1 sube de 0,523 a 0,532. Por tanto, reducir la brecha no basta para cumplir precisión >51%.

La parada interna usa log loss y los últimos 54 días del entrenamiento. El candidato seleccionado llegó al límite de 1.200 árboles en dos ventanas (1.197 en otra): no debe describirse como detenido tempranamente en esas dos ventanas. Los árboles son pequeños y fuertemente regularizados.

Umbral 0,267 fijado en folds 1–2. Fold 3 previamente explorado; no es evaluación independiente. No se evaluó 621–730 ni se sustituyó el modelo principal. Ejecución: `python regularized_search.py --strict`; duración 124 segundos. Configuración y métricas en `summary.json`.
