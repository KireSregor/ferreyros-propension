# Búsqueda orientada a precisión

Se ejecutaron 50 configuraciones nuevas con regularización estricta, umbral que favorece precisión penalizando recall inferior al 55%, y objetivo por peor fold. La configuración se seleccionó exclusivamente en 297–512; se conservó el umbral 0,271855 para 513–620.

| Periodo | Precisión | Recall |
|---|---:|---:|
| Fold 1: validación 297–404 | 50,45% | 55,03% |
| Fold 2: validación 405–512 | 53,37% | 55,04% |
| Fold 3: entrenamiento 243–512 | 51,97% | 56,29% |
| Fold 3: validación 513–620 | 48,37% | 57,36% |

El baseline histórico, con su propio umbral elegido en los mismos folds, obtuvo 48,17% de precisión y 48,52% de recall en el último periodo. La diferencia de precisión es mínima y no se ha establecido significación estadística.

El candidato no mejora la variante estricta anterior (48,56% precisión, 58,80% recall) y no se promueve. No cumple precisión >51%. Esta búsqueda no respalda seguir incrementando únicamente la regularización: reduce la brecha, pero no resuelve la separación de clases.

El modelo elegido usa profundidad 1 y llega al máximo de 1.200 árboles en las tres ventanas; la parada anticipada está configurada, pero no se activó antes del límite para ese candidato. Duración: 148 segundos. Periodo posterior previamente explorado, no independiente; no se evaluó 621–730.

Reproducción: `python regularized_search.py --strict --precision-focus`. Configuración y todas las pruebas en los JSON de esta carpeta.
