# Redes tabulares y ensamblados: resultado medido

**No se alcanzó precisión >60% y recall >60% simultáneamente.** La búsqueda amplía lo probado, pero no demuestra que ese resultado sea imposible con otros modelos o datos.

## Comparación con umbrales congelados

Todas las filas evalúan las mismas visitas de los días 513–620. Cada variante y su umbral se eligen en 297–512. Las diferencias reflejan tanto el modelo como su umbral elegido; no son un efecto puro de cambiar de algoritmo.

| Experimento | Precisión | Recall | F1 | Tiempo |
|---|---:|---:|---:|---:|
| Referencia: tasa histórica | 48.9% | 47.7% | 0.483 | — |
| LightGBM + historial ampliado | 49.2% | 57.7% | 0.531 | 9.47 min |
| TabM + semillas/mezclas | 48.7% | 58.3% | 0.531 | 16.08 min |
| TabM: variables y representaciones | 47.4% | 59.4% | 0.527 | 14.39 min |
| Corrección con días anteriores | 49.2% | 58.2% | 0.533 | 0.02 min |

Los tiempos son los de cada experimento; las dos búsquedas TabM se solaparon y no deben sumarse como tiempo de espera. No incluyen descargar dependencias. La corrección diaria reutiliza predicciones y su tiempo no incluye entrenar el modelo base.

## Qué se amplió

- TabM oficial, tres arquitecturas, tres semillas para la arquitectura seleccionada y mezclas con CatBoost de pesos 25/50/75%.
- Seis variantes adicionales: 46 variables originales frente a 97 ampliadas, menor tasa de aprendizaje, mayor dropout y embeddings numéricos por tramos.
- Límite de 1.000 épocas por ajuste; paciencia de 50 épocas y mínimo de 100 antes de parar. La época se selecciona en los últimos 54 días del entrenamiento. Después se reajusta en todo ese entrenamiento durante la cantidad seleccionada.
- Corrección causal de errores agregados de tienda: 80 configuraciones, incluidas referencias sin corrección. Solo se utilizan resultados de días anteriores.

Se completaron **26 combinaciones de configuración, semilla y ventana** de TabM, cada una con entrenamiento interno y reajuste. Épocas internas ejecutadas: 100–130; épocas seleccionadas: 1–80. Las curvas y tiempos individuales están en `training_times.csv` y en los CSV `*_learning.csv` de cada experimento. Aumentar el límite no obliga a entrenar hasta él cuando empeora la validación.

## Cómo interpretar la evidencia

Las curvas PR recorren todos los umbrales de cada predicción guardada. Si una curva no entra en la zona objetivo, cambiar solamente el umbral de ese modelo no logra 60/60 en esa muestra. Esto **no es una demostración sobre todos los modelos posibles**.

Los días 513–620 ya se habían observado en investigaciones previas: esta comprobación no es un test independiente. Los días 621–730 no se usan para ajustar ni evaluar esta ampliación. Las búsquedas reiteradas sobre validación también pueden sobreajustarla; un resultado final requeriría una evaluación independiente.

No se reemplaza `outputs/model.joblib` ni se publica un nuevo modelo como exitoso. Queda pendiente cumplir el objetivo solicitado o acordar, con evidencia de negocio, otro criterio.

## Fuentes y reproducción

- [TabM oficial](https://github.com/yandex-research/tabm): red tabular con ensamblado eficiente. Se respeta la pérdida por componente y el promedio de probabilidades en inferencia.
- [TabM, ICLR 2025](https://arxiv.org/abs/2410.24210): arquitectura y evaluación; no garantiza una mejora en esta base.
- [Solución de segundo puesto en Kaggle](https://www.kaggle.com/competitions/playground-series-s6e1/writeups/2nd-place-nns-sometimes-work-better-than-gbms): uso de redes, nuevas variables y ensamblados. Sus métricas pertenecen a otro problema y no son una meta transferible.

Dependencias opcionales: `requirements-neural.txt`, después del entorno base. Scripts: `tabm_gpu_audit.py`, `tabm_extended_audit.py`, `online_calibration_audit.py`. Cada búsqueda guarda configuración, predicciones, curvas internas y huellas de código/datos. Los archivos existentes no se reutilizan si cambian las huellas.

Para repetir con la versión actual sin mezclar cachés históricos: `python tabm_gpu_audit.py --output-dir outputs/tabm_gpu_repeat` y `python tabm_extended_audit.py --output-dir outputs/tabm_extended_repeat`. El argumento de carpeta y la representación por tramos se añadieron durante esta investigación; las huellas originales se conservan y una repetición usa una carpeta nueva.

`python consolidate_neural.py` reconstruye esta comparación y la sección 11 del notebook desde resultados guardados, sin reentrenar ni evaluar el test.
