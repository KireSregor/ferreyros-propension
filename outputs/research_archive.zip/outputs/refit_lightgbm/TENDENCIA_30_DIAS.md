# Comparación de tendencias personales en bloques de 30 días

Se tomó como inspiración el uso de frecuencia, ratios de recompra, recencia e intervalos personales en soluciones de Kaggle Instacart: [código del participante](https://github.com/panyao/instacart-solution) y [entrevista al segundo puesto](https://medium.com/kaggle-blog/instacart-market-basket-analysis-feda2700cded). Es un problema distinto; estas referencias fundamentan hipótesis, no garantizan mejoras.

Ya existían tasas acumuladas en los últimos 30/60/90 días. La nueva prueba añade **bloques separados**: últimos 1–30, 31–60, 61–90 y 91–120 días antes de cada visita. Para cada bloque se cuentan visitas, compras y compras/visitas. Se calculan cambios de tasa, aceleración, cambios de visitas/compras y soporte mínimo de la comparación. Una variante suaviza la tasa reciente hacia el historial de 31–120 días, en lugar de hacia toda la vida del cliente.

Una ventana sin visitas no equivale a tasa cero: se conserva como faltante y se informa su soporte. Los bloques son días relativos, no meses de calendario. El resultado del día actual se excluye. Pasaron invariancia de prefijo temporal y perturbación de resultados del día actual.

## Ablación controlada

Mismos parámetros LightGBM y ventana de entrenamiento. Umbral elegido por el mismo procedimiento en días 297–512.

| Variables | Precisión selección | Recall selección |
|---|---:|---:|
| Control anterior | 51,50% | 56,54% |
| Control + tendencia mensual | 51,50% | 56,08% |
| Tendencia reciente sin tasas/conteos de toda la vida ni fases artificiales | 51,51% | 55,05% |

El control ganó la selección. Por eso no se usó el periodo posterior para escoger entre las variantes mensuales. El control posterior conserva 47,45% de precisión y 57,79% de recall.

**Conclusión:** con esta configuración fija, añadir los ratios por bloques no mejora la selección. No demuestra que toda representación de tendencia sea inútil. No se promueve la nueva función al modelo principal. Las métricas de selección también pueden ser optimistas por búsquedas previas; el periodo posterior ya se había observado.

Código: `monthly_trend_features` en `src/ferreyros_propension/feature_research.py`; ejecución: `python test_monthly_trends.py`. Datos completos en `monthly_trends.json`. No se evaluaron días 621–730.

## Diagnóstico posterior solicitado

Después de la selección, se compararon las tres variantes en días 513–620 para investigar la caída. Se conservaron sus respectivos umbrales de selección; no se ajustaron con este resultado.

| Variables | Precisión posterior | Recall posterior | F1 |
|---|---:|---:|---:|
| Control | 47,45% | 57,79% | 0,521 |
| Control + tendencia mensual | 47,93% | 58,08% | 0,525 |
| Reciente sin historial de toda la vida ni fases | 49,62% | 53,06% | 0,513 |

Añadir tendencias mejoró ligeramente ambas métricas en este periodo, aunque no evitó la caída de precisión respecto a selección (51,50% a 47,93%). Esta comparación posterior es diagnóstica y no confirma una mejora independiente. Datos en `monthly_later_diagnostic.json`.
