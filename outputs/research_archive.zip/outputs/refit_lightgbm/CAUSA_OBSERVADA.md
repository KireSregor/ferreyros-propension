# Localización del deterioro

Se mantuvieron parámetros, variables, semilla y umbral. Se entrenó hasta el día 404 y se puntuaron dos periodos posteriores con el mismo modelo; después se comparó con un modelo reajustado hasta 512 en las mismas visitas de 513–620.

| Modelo y periodo | Precisión | Recall | Falsas alarmas entre no compradores |
|---|---:|---:|---:|
| Entrenado hasta 404; días 405–512 | 51,33% | 58,49% | 18,77% |
| El mismo modelo; días 513–620 | 48,78% | 58,32% | 21,58% |
| Reajustado hasta 512; días 513–620 | 47,45% | 57,79% | 22,55% |

La caída no se origina exclusivamente al reentrenar: el modelo congelado ya pierde 2,55 puntos de precisión al cambiar de periodo. El reajuste añade otros 1,33 puntos de deterioro, con 58 falsas alarmas más y 11 compras detectadas menos sobre exactamente las mismas visitas. Son diferencias observadas, no una descomposición causal generalizable.

## Dónde aparecen los errores del modelo congelado

- Clientes con tasa histórica entre 30% y 50%: entre sus visitas sin compra, falsas alarmas de 48,9% a 60,4%; los casos sin compra son casi iguales (798 y 801), pero las falsas alarmas pasan de 390 a 484.
- Última compra hace 7–30 días: falsas alarmas de 26,8% a 31,6%; los casos sin compra pasan de 2.061 a 2.179 y las falsas alarmas de 552 a 689.
- Sin promociones: falsas alarmas de 13,0% a 19,1%. No es evidencia de que la ausencia de promociones cause el error; las poblaciones y otras condiciones cambian.

Estos grupos se solapan: sus incrementos no se suman. Las contribuciones del modelo sobre visitas sin compra muestran mayor empuje hacia compra de la tasa reciente suavizada y las compras acumuladas; una fase relativa de 30 días también aporta. Las contribuciones explican la predicción del modelo, no causalidad del negocio.

## Mezcla de clientes frente a cambios dentro de clientes

Con los 500 clientes presentes en ambos periodos, ponderar las tasas previas de falsas alarmas de cada cliente por sus visitas posteriores sin compra predice unas 1.209 falsas alarmas. Se observaron 1.281. Por tanto, la mezcla de visitantes por cliente no explica todo el deterioro. Esta estandarización es descriptiva y las tasas individuales tienen incertidumbre.

## Conclusión defendible

El patrón de historial que antes identificaba compradores produce más falsas alarmas después, principalmente en compradores de propensión intermedia. El reajuste evaluado tampoco corrige ese cambio y lo agrava. La proporción global de compras prácticamente constante descarta la prevalencia como explicación principal.

No se ha identificado por qué cambió la relación historial–compra: necesidad, inventario, intención de visita y otros contextos no están observados. Sobreajuste, variación temporal y efectos de entrenamiento no quedan completamente separados. El resultado no permite afirmar ausencia de sobreajuste.

Reproducción: `python diagnose_errors.py`. Datos de soporte: `error_cause.json`, `error_segments.csv`, `contribution_changes.csv`. Solo se usan días hasta 620; la comprobación ya había sido inspeccionada y no es independiente.
