# Por qué cayó la precisión

La proporción real de compras prácticamente no cambió: 26,066% en selección y 26,056% después. No explica la caída de precisión de 51,5% a 47,4%.

El cambio observable principal es la tasa de falsos positivos: pasó de 18,77% a 22,55% entre visitas sin compra. El recall se mantuvo (56,54% a 57,79%). A igual tamaño que el periodo posterior, conservar la tasa anterior habría producido aproximadamente 1.115 falsas alarmas en lugar de 1.339: unas 224 adicionales.

El AUC bajó de 0,758 a 0,748 y AP de 0,580 a 0,553. Hay deterioro de separación entre clases, además de un cambio del punto operativo. La probabilidad media no está inflada globalmente: 25,22% frente a 26,06% de compras. Esto no excluye descalibración local alrededor del umbral; una media no es una prueba completa de calibración.

Cambiar solo la prevalencia, conservando las tasas de detección y falsas alarmas anteriores, daría 51,49% de precisión: prácticamente el 51,5% original. La menor frecuencia de compras queda descartada como explicación principal.

Bootstrap emparejado por cliente, 2.000 remuestreos y umbral fijo: intervalo del cambio de precisión de −6,58 a −1,24 puntos porcentuales. No incluye incertidumbre de selección, dependencia entre días ni cambios de entrenamiento; no es una prueba causal.

Cada ventana usa un modelo reajustado con un entrenamiento distinto. Estos resultados no separan de forma concluyente sobreajuste, cambio de comportamiento e inestabilidad del reajuste. Las 40 configuraciones y el umbral se seleccionaron sobre los mismos periodos, lo que añade optimismo de selección. No corresponde afirmar ausencia de sobreajuste.

Siguiente diagnóstico útil: comparar el mismo modelo congelado y el reajustado en periodos posteriores, y localizar qué segmentos generan las falsas alarmas adicionales. Antes de cambiar parámetros de nuevo conviene resolver esa distinción.

Los números reproducidos quedan en `diagnosis.json`; las predicciones de selección en `selection_predictions.csv`. No se evaluaron días 621–730.
