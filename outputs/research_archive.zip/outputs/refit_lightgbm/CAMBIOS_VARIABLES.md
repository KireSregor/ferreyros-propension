# Variables que cambiaron y relación con el deterioro

Comparación descriptiva de días 405–512 frente a 513–620. El modelo explicativo se mantiene congelado, entrenado con días 135–404. Los grupos se definieron por significado de variables, sin seleccionar únicamente las contribuciones favorables a una hipótesis.

## Hallazgo principal: el historial reciente separa peor las clases

Entre visitas con tasa reciente suavizada superior al 50%, la compra observada pasó de 66,5% (1.248 visitas) a 59,6% (1.154). El grupo de tasa reciente 30–50% aumentó de 1.175 a 1.595 visitas y su conversión subió de 33,4% a 37,6%. No hubo una caída uniforme de la compra: cambió la distribución y el poder discriminante del historial.

Las contribuciones agrupadas del modelo respaldan ese mecanismo predictivo. En no compradores, el historial reciente pasó de −0,199 a −0,146 log-odds: los protegía menos de recibir una alerta. En compradores, pasó de +0,591 a +0,532: los favorecía menos. La distancia entre ambos promedios se contrajo de 0,789 a 0,678. Las contribuciones explican el modelo; no prueban causalidad comercial.

## Cambios comerciales comprobados, pero no explicación directa principal de las falsas alarmas

Precio medio marca 3: 2,027 a 2,059. Marca 4: 2,189 a 2,228. Promoción marca 1: 24,2% a 35,9% de visitas. Respecto al entrenamiento congelado, 87,2% de las visitas posteriores tienen el precio de marca 3 fuera del rango observado y 86,4% el de marca 4. Esto identifica un problema real de extrapolación para árboles.

Sin embargo, la contribución conjunta de precios/promociones en no compradores disminuyó de +0,042 a −0,018 log-odds. En promedio, esas variables empujaron hacia menos compras, no hacia más falsas alarmas. Por eso no atribuimos el aumento directamente a los precios solo por detectar un cambio de distribución. El cambio comercial podría afectar relaciones condicionales e interacciones; eso no queda aislado aquí.

## Señales acumulativas y fases añaden presión hacia compra

En no compradores, los conteos acumulados, día y antigüedad aportaron −0,102 antes y −0,077 después. Las fases relativas 7/30 días pasaron de −0,003 a +0,028. Ambos movimientos empujan más hacia compra. Son asociaciones internas del modelo; los grupos se correlacionan y no permiten sumar porcentajes causales de errores.

## Corrección de la interpretación anterior

El grupo de tasa histórica 30–50% no compró menos: su conversión fue 37,1% y 37,7%. Que sus falsas alarmas aumenten no demuestra que esos clientes redujeran su compra. El deterioro observado corresponde a una relación predictiva menos fiable, con cambios dentro de los grupos y en las variables que el modelo usa.

## Conclusión

La explicación respaldada es una combinación de **menor separación del historial reciente**, **variables acumulativas/fases que elevan alertas entre no compradores** y **precios fuera del soporte del entrenamiento**. La prueba del modelo congelado demuestra que el deterioro no nace únicamente del reajuste; el reajuste agrega errores adicionales. No se identifica la causa comercial última ni se demuestra que toda la caída sea sobreajuste.

La siguiente intervención justificada sería comparar, con validación temporal, un modelo sin fases artificiales ni conteos absolutos y con precios normalizados respecto a su historial. Esta es una hipótesis para probar, no una mejora ya demostrada.

Soporte numérico: `feature_drift.csv`, `group_contributions.csv`, `error_cause.json` y `error_segments.csv`. No se analizan días 621–730. Estos periodos ya fueron explorados y no constituyen un test independiente.
