# Segunda auditoría del objetivo 60/60

Resultado: lightgbm_dynamic, seleccionado en días297–512. Umbral congelado 0.30308. Comprobación días513–620: precisión 49.25%, recall 57.70%, F1 0.5314. Compras detectadas 1207, omitidas 885, falsas alarmas 1244.

La comprobación ya había sido observada en fases anteriores. No representa una muestra externa independiente. No se usa el periodo621–730.

## Evidencia y alcance

- Auditoría independiente verificó 24.802 filas de predicciones, claves, orden, target y folds. No encontró un error probado que explique la brecha. Las mezclas de la ronda anterior estaban alineadas.
- Las variables históricas son válidas para scoring secuencial con actualización tras observar resultados, no para pronosticar todo un horizonte sin feedback.
- Confirmado en entrenamiento: día256 tiene102visitas y0compras. Es una anomalía que puede representar un shock de tienda o un problema de registro. Sin documentación adicional no se puede etiquetar como corrupción ni eliminar para favorecer métricas.
- Se añadieron tasas y volumen de tienda en días previos1/3/7/14/30/60, cambios de tasa cliente/tienda, cambios de precios desde visita anterior y cantidades/marca de visita anterior. Se verificó invariancia frente a eventos futuros y modificación de todos los resultados del día actual.
- Nueva búsqueda60trialsLightGBM, ventanas de entrenamiento180/270/365/todo, mayor rango de capacidad y regularización. Cinco variantesCatBoost incluidas la configuración original con variables dinámicas y cuatro combinaciones de profundidad/iteraciones/ventana.
- Auditoría complementaria:14candidatos de regresión logística personalizada y tasasMarkov cliente/estado. Ganador en comprobación: precisión 50.13%, recall 55.88%.
- El objetivo principal aquí es maximizar la menor de precisión y recall; el umbral usa el mismo criterio y se congela antes de la comprobación.
- Tiempo experimento dinámico: 9.47min. Personalización: 27.8s. No se suman como duración de pared porque se ejecutaron en paralelo.

## Conclusión válida

No se alcanzó el objetivo60/60 en estas pruebas. La búsqueda produjo mejoras parciales y candidatos que sobreajustan, pero no prueba un techo teórico de la base. El código fuente del generador y la distribución completa que produce los datos no están disponibles; no podemos emitir una prueba irrefutable de que ningún modelo alcanzaría60/60. Para cada ranking concreto sí podemos comprobar exhaustivamente todos sus umbrales; esa conclusión no se extiende a modelos desconocidos.

Comparar con resultados de otra base, aun con más clases o mayor suciedad, no establece el rendimiento alcanzable aquí: importan la información predictiva disponible y el protocolo de validación.

Fuentes y trazabilidad: scripts audit_6060_round2.py e independent_personalization.py; selection.csv, trials.csv, winner_check.csv y summary.json. No se altera el modelo principal porque no se demostró cumplimiento.
