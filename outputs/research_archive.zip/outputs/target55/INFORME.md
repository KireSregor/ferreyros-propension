# Objetivo pendiente: precisión y recall superiores al 55%

Todas las variantes evalúan las mismas 8.029 visitas de días 513–620, con 2.092 compras. Los umbrales se fijaron previamente. Este periodo ya se había inspeccionado y no es una evaluación independiente. No se utilizó 621–730 en estas investigaciones.

| Variante | Precisión | Recall | F1 |
|---|---:|---:|---:|
| Corrección diaria | 49.2% | 58.2% | 0.533 |
| Ensamblado aprendido | 53.1% | 48.6% | 0.507 |
| Reentrenamiento periódico | 49.5% | 56.9% | 0.530 |
| Respuesta personal a condiciones | 49.3% | 57.3% | 0.530 |
| Pronóstico temporal | 51.7% | 50.5% | 0.511 |
| Interacciones restringidas | 48.3% | 59.4% | 0.533 |

## Qué se comprobó en esta ronda

- Pronóstico diario de las desviaciones respecto a la propensión histórica de los visitantes, usando regresión regularizada y días anteriores; ciclos relativos de 14/60/90/180/365 días. Tres controles y 30 configuraciones Optuna. Duración: 54,2 segundos.
- Modelos aditivos o con interacciones de dos variables; 46/97 predictores, dos regularizaciones y dos cantidades de iteraciones. Dieciséis configuraciones. Duración: 21,4 segundos.
- Selección por la menor precisión/recall entre las dos ventanas, usando un umbral común. Total: 100 ajustes de los modelos principales, además de los ajustes auxiliares del pronóstico diario.
- Las variables temporales pasaron controles de invariancia ante datos futuros y resultados del día actual. Se verificaron las claves cliente/día y las métricas guardadas de todas las variantes de esta comparación.

## Resultado y límites

Ninguna variante cumple 55/55 con el umbral fijado. El barrido exhaustivo de umbrales tampoco encuentra 55/55 para ninguna de estas predicciones en la muestra de comprobación. Cambiar solamente su umbral no resuelve el requisito en esa muestra. Los máximos del CSV son diagnósticos optimistas, no resultados de una política elegida antes de evaluar.

Esto no prueba que cualquier modelo posible esté limitado a estos resultados. Sí descarta presentar estas variantes como una solución del requisito. Reducir capacidad y modelar cambios temporales no produjo una mejora suficiente. La causa restante no está identificada de forma concluyente.

La validación ha guiado muchas investigaciones. Un éxito posterior sobre ella necesitaría confirmación en datos realmente independientes. No se reemplaza el modelo principal ni se declaran resueltos el objetivo o el sobreajuste.

## Reproducir

`python temporal_signal_audit.py` y `python additive_audit.py`. Las configuraciones, predicciones por ventana y tiempos quedan en sus carpetas de outputs. `comparison.csv` incluye el diagnóstico exhaustivo a 55%.
