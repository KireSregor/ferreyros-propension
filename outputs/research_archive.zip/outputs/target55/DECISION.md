# Candidato recomendado para revisión

Se recomienda **LightGBM con historial ampliado**, sin la corrección diaria adicional. En los días 513–620 y con umbrales fijados en días 297–512, obtuvo precisión 49,2%, recall 57,7% y F1 0,531. La referencia histórica obtuvo 48,9%, 47,7% y 0,483, respectivamente, sobre las mismas 8.029 visitas. Los umbrales de ambos se seleccionaron por separado con el mismo criterio; la comparación no atribuye el cambio exclusivamente al algoritmo.

La corrección diaria obtuvo F1 0,533, pero requirió una operación adicional y su mejora sobre LightGBM fue de apenas 0,002 puntos de F1 en un periodo ya explorado. Esa diferencia no establece una mejora robusta. Se prefiere la alternativa más sencilla hasta disponer de evidencia adicional.

**Limitación importante:** los indicadores de entrenamiento fueron mayores que los de validación; existe evidencia de sobreajuste. Además, 513–620 ya se utilizó para explorar variantes y no constituye una evaluación independiente. No se puede afirmar que el candidato esté libre de sobreajuste ni que cumpla el objetivo de 55% en ambas métricas. No se ha sustituido el modelo persistido de producción por este candidato de investigación.

Configuración, variables, umbral y métricas: [resultado del candidato](../audit_round2/summary.json). Comparación de otras alternativas: [informe](INFORME.md). El periodo 621–730 no se evaluó para esta selección.
