"""Independent personalized models, using only development data through day 620."""

import json
import os
from pathlib import Path
from time import perf_counter

os.environ["OMP_NUM_THREADS"] = "2"
os.environ["MKL_NUM_THREADS"] = "2"
os.environ["OPENBLAS_NUM_THREADS"] = "2"

import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    average_precision_score,
    f1_score,
    log_loss,
    precision_recall_curve,
    precision_score,
    recall_score,
)
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from threadpoolctl import threadpool_limits

from ferreyros_propension.feature_research import enriched_features

OUT = Path("outputs/independent_audit")
FOLDS = [(296, 404), (404, 512)]


def frontier(y, p):
    precision, recall, thresholds = precision_recall_curve(y, p)
    precision, recall = precision[:-1], recall[:-1]
    index = np.argmax(np.minimum(precision, recall))
    return {
        "precision": float(precision[index]),
        "recall": float(recall[index]),
        "threshold": float(thresholds[index]),
        "balance": float(min(precision[index], recall[index])),
        "precision_at_recall60": float(precision[recall >= 0.6].max(initial=0)),
        "recall_at_precision60": float(recall[precision >= 0.6].max(initial=0)),
        "ap": float(average_precision_score(y, p)),
        "logloss": float(log_loss(y, p)),
        "feasible": bool(((precision > 0.6) & (recall > 0.6)).any()),
    }


def add_markov(events, x):
    """Partial-pooling Markov rates update after each observed visit, never before."""
    previous = events.groupby("id").incidencia_compra.shift().fillna(-1).astype(int)
    second = events.groupby("id").incidencia_compra.shift(2).fillna(-1).astype(int)
    features = x.copy()
    for name, state in [("previous", previous), ("pair", previous * 3 + second)]:
        groups = events.groupby([events.id, state], sort=False)
        visits = groups.cumcount()
        purchases = groups.incidencia_compra.cumsum() - events.incidencia_compra
        for strength in [3, 10, 30]:
            features[f"markov_{name}_{strength}"] = (
                purchases + strength * events.tasa_previa
            ) / (visits + strength)
        features[f"markov_{name}_support"] = visits
    return features


def design(train, valid, random_slopes):
    categorical = list(train.select_dtypes(include=["object", "string"]).columns)
    numeric = list(train.columns.difference(categorical))
    imputer = SimpleImputer(strategy="median", add_indicator=True)
    scaler = StandardScaler()
    a = scaler.fit_transform(imputer.fit_transform(train[numeric]))
    b = scaler.transform(imputer.transform(valid[numeric]))
    encoder = OneHotEncoder(handle_unknown="ignore", sparse_output=True)
    cat_a, cat_b = (
        encoder.fit_transform(train[categorical]),
        encoder.transform(valid[categorical]),
    )
    blocks_a, blocks_b = [sparse.csr_matrix(a), cat_a], [sparse.csr_matrix(b), cat_b]
    if random_slopes:
        ids = OneHotEncoder(handle_unknown="ignore", sparse_output=True)
        id_a = ids.fit_transform(train[["cliente_conocido"]])
        id_b = ids.transform(valid[["cliente_conocido"]])
        slope_names = [
            "compra_visita_lag_1",
            "dias_desde_visita",
            "dias_desde_compra",
            "precio_promedio",
            "n_promociones",
            "fase_7_sin",
            "fase_7_cos",
            "tasa_ewm_5",
            "visitas_desde_compra",
        ]
        for name in slope_names:
            col = numeric.index(name)
            blocks_a.append(id_a.multiply(a[:, col, None]))
            blocks_b.append(id_b.multiply(b[:, col, None]))
    return sparse.hstack(blocks_a).tocsr(), sparse.hstack(blocks_b).tocsr()


def fit_cv(events, x, params, folds):
    rows = []
    for number, (cut, end) in enumerate(folds):
        train = events.dia_visita.le(cut)
        valid = events.dia_visita.between(cut + 1, end)
        a, b = design(x[train], x[valid], params["random_slopes"])
        model = LogisticRegression(
            C=params["C"],
            solver="lbfgs",
            max_iter=1000,
            class_weight=params["class_weight"],
            random_state=42,
        )
        model.fit(a, events.loc[train, "incidencia_compra"])
        rows.append(
            pd.DataFrame(
                {
                    "id": events.loc[valid, "id"],
                    "dia_visita": events.loc[valid, "dia_visita"],
                    "y": events.loc[valid, "incidencia_compra"],
                    "p": model.predict_proba(b)[:, 1],
                    "fold": number,
                }
            )
        )
    return pd.concat(rows)


def main():
    started = perf_counter()
    OUT.mkdir(exist_ok=True, parents=True)
    raw = pd.read_csv("Dataset/compras_data.csv")
    raw = raw[raw.dia_visita.le(620)]
    events, x = enriched_features(raw)
    x = add_markov(events, x)
    # Prefix invariance for conditional histories and sequence rates.
    early = raw[raw.dia_visita.le(296)]
    early_events, early_x = enriched_features(early)
    early_x = add_markov(early_events, early_x)
    pd.testing.assert_frame_equal(
        x[events.dia_visita.le(296)].reset_index(drop=True), early_x
    )
    candidates = []
    predictions = {}
    for slopes in [False, True]:
        for c in [0.003, 0.03, 0.3, 3.0]:
            for balanced in [None]:
                params = {"random_slopes": slopes, "C": c, "class_weight": balanced}
                name = f"logistic_personal_slopes{int(slopes)}_c{c}"
                tick = perf_counter()
                frame = fit_cv(events, x, params, FOLDS)
                frame.to_csv(OUT / f"{name}_selection_predictions.csv", index=False)
                predictions[name] = frame
                row = {
                    "candidate": name,
                    "params": params,
                    "seconds": perf_counter() - tick,
                    **frontier(frame.y, frame.p),
                }
                candidates.append(row)
                print(json.dumps(row), flush=True)
                pd.DataFrame(candidates).to_csv(
                    OUT / "personalization_selection.csv", index=False
                )
    # Standalone dynamic state-conditioned rates are deliberately model-free.
    valid = events.dia_visita.between(297, 512)
    for col in [c for c in x if c.startswith("markov_") and not c.endswith("support")]:
        row = {
            "candidate": col,
            "params": None,
            "seconds": 0,
            **frontier(events.loc[valid, "incidencia_compra"], x.loc[valid, col]),
        }
        candidates.append(row)
    selected = max(candidates, key=lambda row: row["balance"])
    threshold = selected["threshold"]
    if selected["params"] is None:
        mask = events.dia_visita.between(513, 620)
        check = pd.DataFrame(
            {
                "id": events.loc[mask, "id"],
                "dia_visita": events.loc[mask, "dia_visita"],
                "y": events.loc[mask, "incidencia_compra"],
                "p": x.loc[mask, selected["candidate"]],
            }
        )
    else:
        check = fit_cv(events, x, selected["params"], [(512, 620)])
    predicted = check.p.ge(threshold)
    result = {
        "selected": selected,
        "check": {
            "precision": precision_score(check.y, predicted),
            "recall": recall_score(check.y, predicted),
            "f1": f1_score(check.y, predicted),
            "threshold": threshold,
            "ap": average_precision_score(check.y, check.p),
            "logloss": log_loss(check.y, check.p),
        },
        "seconds": perf_counter() - started,
        "scope": "Selection297-512; chronological check513-620; no621+; previously seen windows not pristine.",
    }
    check.to_csv(OUT / "personalization_check_predictions.csv", index=False)
    pd.DataFrame(candidates).to_csv(OUT / "personalization_selection.csv", index=False)
    (OUT / "personalization_summary.json").write_text(json.dumps(result, indent=2))
    print("FINISHED", json.dumps(result), flush=True)


if __name__ == "__main__":
    with threadpool_limits(limits=2):
        main()
