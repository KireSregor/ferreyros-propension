"""TabM feature ablation and numerical embeddings under temporal validation."""

import argparse
import hashlib
import json
from pathlib import Path
from time import perf_counter

import pandas as pd
import torch

from audit_6060_round2 import balanced_point, dynamic_features
from ferreyros_propension.data import load_data
from investigate_6060 import operating_points, score_at
from tabm_gpu_audit import fit_fold

OUT = Path("outputs/tabm_extended")


def main():
    started = perf_counter()
    OUT.mkdir(exist_ok=True)
    torch.set_num_threads(4)
    torch.set_float32_matmul_precision("high")
    raw = load_data("Dataset/compras_data.csv")
    events, features = dynamic_features(raw[raw.dia_visita.le(620)])
    features = features.drop(columns="cliente_conocido")
    # The first 46 columns are the original predictor set, before research features.
    assert features.columns[45] == "precio_relativo_5"
    spaces = {"compact": features.iloc[:, :46], "full": features}
    manifest = {
        "source": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "training_source": hashlib.sha256(
            Path("tabm_gpu_audit.py").read_bytes()
        ).hexdigest(),
        "data": hashlib.sha256(
            Path("Dataset/compras_data.csv").read_bytes()
        ).hexdigest(),
        "columns": {key: list(frame.columns) for key, frame in spaces.items()},
    }
    manifest_path = OUT / "manifest.json"
    if manifest_path.exists() and json.loads(manifest_path.read_text()) != manifest:
        raise RuntimeError("Changed experiment: use a new output directory.")
    manifest_path.write_text(json.dumps(manifest, indent=2))
    records, candidates = [], {}
    for space, frame in spaces.items():
        for variant, embedding, learning_rate, dropout in [
            ("slow", False, 0.0001, 0.35),
            ("piecewise", "piecewise", 0.0003, 0.2),
            ("regularized", True, 0.0003, 0.5),
        ]:
            name = f"{space}_{variant}"
            config = {
                "width": 128,
                "blocks": 2,
                "dropout": dropout,
                "k": 16,
                "embeddings": embedding,
                "lr": learning_rate,
                "decay": 0.01,
            }
            predicted = pd.concat(
                [
                    fit_fold(events, frame, cut, end, name, 42, OUT, config)
                    for cut, end in [(296, 404), (404, 512)]
                ]
            )
            balance, threshold = balanced_point(predicted.y, predicted.p)
            records.append(
                {
                    "candidate": name,
                    "balance": balance,
                    **score_at(predicted.y, predicted.p, threshold),
                    **operating_points(predicted.y, predicted.p),
                }
            )
            candidates[name] = (space, config)
            pd.DataFrame(records).to_csv(OUT / "selection.csv", index=False)
            print("CANDIDATE", name, balance, flush=True)
    selected = max(records, key=lambda row: row["balance"])
    name = selected["candidate"]
    space, config = candidates[name]
    check = fit_fold(events, spaces[space], 512, 620, name, 42, OUT, config)
    check.to_csv(OUT / "check.csv", index=False)
    summary = {
        "selected": selected,
        "configuration": config,
        "check": score_at(check.y, check.p, selected["threshold"]),
        "frontier_diagnostic": operating_points(check.y, check.p),
        "seconds": perf_counter() - started,
        "scope": "Selection297-512; previously seen check513-620; no621+.",
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2))
    print("FINISHED", json.dumps(summary), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, default=OUT)
    OUT = parser.parse_args().output_dir
    main()
