"""Consolida evidencia 60/60 y la integra al notebook sin repetir experimentos."""

import json
from pathlib import Path

import matplotlib.pyplot as plt
import nbformat
import numpy as np
import pandas as pd
from nbclient import NotebookClient
from sklearn.metrics import precision_recall_curve

from ferreyros_propension.plotting import BLUE, NAVY, TEAL, apply_theme
from investigate_6060 import score_at

OUT = Path("outputs/research_6060")
summary = json.loads((OUT / "summary.json").read_text())
winner = summary["winner_selected_first_two_folds"]
frame = pd.read_csv(OUT / f"{winner}_oof.csv")
tuning, check = frame[frame.fold.lt(2)], frame[frame.fold.eq(2)]
p, r, t = precision_recall_curve(tuning.y, tuning.p)
index = int(np.argmax(np.minimum(p[:-1], r[:-1])))
threshold = float(t[index])
actual = score_at(check.y, check.p, threshold)
# Cluster bootstrap with frozen model and threshold, never optimize inside draws.
groups = [g for _, g in check.groupby("id")]
rng = np.random.default_rng(42)
replicates = []
for _ in range(300):
    sample = pd.concat([groups[i] for i in rng.integers(0, len(groups), len(groups))])
    replicates.append(score_at(sample.y, sample.p, threshold))
intervals = pd.DataFrame(replicates)[["precision", "recall", "f1"]].quantile(
    [0.025, 0.975]
)
intervals.to_csv(OUT / "fixed_threshold_client_bootstrap.csv")
summary["balanced_threshold_selected_first_two_folds"] = threshold
summary["balanced_threshold_chronological_check"] = actual
summary["cluster_bootstrap_interval"] = intervals.to_dict()
(OUT / "summary.json").write_text(json.dumps(summary, indent=2))

apply_theme()
figure, axes = plt.subplots(1, 2, figsize=(13, 5))
for axis, (label, part) in zip(
    axes,
    [
        ("Desarrollo de mejoras: días 297–512", tuning),
        ("Comprobación: días 513–620", check),
    ],
    strict=True,
):
    precision, recall, _ = precision_recall_curve(part.y, part.p)
    axis.plot(recall, precision, color=BLUE, label=winner.replace("_", " "))
    base = pd.read_csv(OUT / "catboost_original_oof.csv")
    baseline = base[base.fold.lt(2)] if part is tuning else base[base.fold.eq(2)]
    bp, br, _ = precision_recall_curve(baseline.y, baseline.p)
    axis.plot(br, bp, color=TEAL, label="CatBoost original")
    axis.axvline(0.6, color=NAVY, ls="--", lw=1)
    axis.axhline(0.6, color=NAVY, ls="--", lw=1)
    axis.fill_between([0.6, 1], 0.6, 1, color="green", alpha=0.07)
    axis.set(
        title=label,
        xlabel="Recall: fracción de compras detectadas",
        ylabel="Precisión: aciertos entre alertas",
        xlim=(0, 1),
        ylim=(0, 1),
    )
    axis.legend(fontsize=8)
figure.suptitle(
    "Objetivo: superar 60 % de precisión y recall simultáneamente", fontsize=15
)
figure.tight_layout()
figure.savefig(OUT / "precision_recall_6060.png", dpi=170)
plt.close(figure)

selection = pd.read_csv(OUT / "selection.csv").sort_values(
    "balanced_frontier", ascending=False
)
checks = pd.read_csv(OUT / "chronological_check.csv")
best = selection.iloc[0]
report = f"""# Diagnóstico del objetivo de precisión y recall >60 %

## Conclusión

El candidato seleccionado en días 297–512 es `{winner}`. Con un umbral balanceado de {threshold:.4f}, fijado antes de la comprobación, obtiene en días 513–620 precisión **{actual["precision"]:.1%}**, recall **{actual["recall"]:.1%}** y F1 **{actual["f1"]:.3f}**. Cumple 60/60: **{actual["precision"] > 0.6 and actual["recall"] > 0.6}**.

Esto es evidencia de que los candidatos y variables probados no alcanzan el requisito, NO una demostración matemática de que ningún modelo pueda alcanzarlo. No se vuelve a consultar ni puntuar días 621–730. Las ventanas de desarrollo ya se habían usado históricamente; la comprobación temporal no es una muestra externa virgen.

## Datos e hipótesis

- EDA adicional limitado a días 1–296; 500 clientes, observaciones repetidas por visita.
- Coincidencia exacta de valores y orden de columnas renombradas con la base pública de k-bosko (solo se contrasta hasta día 620). Su README atribuye la base al curso Customer Analytics; no proporciona un techo predictivo ni prueba un mecanismo generador.
- Después de una visita con compra, conversión observada 40,3 %; después de una sin compra, 18,9 %. Asociación, no causalidad ni garantía de predictibilidad.
- Dentro de un día, todos reciben los mismos precios y promociones; las filas no son miles de experimentos comerciales independientes.
- Nuevas hipótesis: lags 1/2/3; últimas 3/5/10/20 visitas; medias exponenciales; ventanas 7/14 días; cadencia individual de visita/compra; recencia relativa; cantidad previa; precio/promoción ponderados por preferencias históricas; antigüedad y fases relativas 7/30; categoría cliente conocido.
- Identidad se probó como categoría, sin usar el código numérico como señal ordenada. No se incluyó tamaño de ciudad (excluido por diccionario), marca/cantidad actuales ni conversiones del día completo.
- Invariancia ante futuro y resultado actual comprobada en la ejecución. El historial se actualiza después de cada resultado observado, según el escenario secuencial ya definido.

## Pruebas

- Seis familias originales, comparación de todos sus umbrales.
- Dos espacios de LightGBM, 25 pruebas Optuna cada uno, dos folds por prueba; objetivo directo: máximo de la menor de precisión y recall al recorrer umbrales.
- CatBoost con variables enriquecidas y dos pesos de clase; tres mezclas simples 50/50.
- Selección de candidato solo en OOF297–512. Primera evaluación de cada familia usa parámetros previamente seleccionados en desarrollo: existe optimismo heredado de selección, declarado.
- Umbral balanceado seleccionado en 297–512; se congela para 513–620. Se conserva también la alternativa que maximiza F1; no se selecciona por el resultado posterior.
- Los máximos obtenidos recorriendo umbrales sobre el mismo conjunto son diagnósticos optimistas, no estimaciones de despliegue. Su utilidad: si ni siquiera allí aparece 60/60, un cambio de umbral de ese ranking no puede producirlo en esa muestra.
- Bootstrap emparejado por cliente: intervalos para modelo y umbral fijos. No incluye incertidumbre de selección ni todo el cambio temporal.

## Qué indican los límites observados

En las dos primeras ventanas, ningún candidato alcanza 60/60: **{not selection.feasible_6060.any()}**. La mejor menor-métrica es {best.balanced_frontier:.1%}, frente al 60 % solicitado. El conjunto de curvas muestra el compromiso real: al capturar compras menos evidentes se incorporan también no-compras.

El entrenamiento y la validación se conservan en `*_train_metrics.csv`: si entrenar memoriza más compras y no mejora validación, aumentar capacidad no basta. No confundimos esta observación con un límite teórico de la base. Ningún resultado autoriza prometer que solo más Optuna logrará el objetivo.

Posibles avances requieren hipótesis nuevas y evaluación temporal: información previa sobre intención de compra, inventario del hogar, necesidad del producto o contexto de visita, si el negocio puede capturarla. No existe evidencia aquí para prometer cuánto mejoraría. Ampliar la búsqueda con otra familia o representación sigue siendo posible; esta investigación es finita.

## Archivos y reproducción

`python investigate_6060.py` ejecuta auditoría, variables, búsqueda y comparación. `python consolidate_6060.py` construye esta síntesis y actualiza el notebook. Duración de investigación: {summary["seconds"] / 60:.2f} minutos; consolidación no incluida. Resultados completos en CSV/JSON; Optuna en SQLite (no publicar la base por defecto).

Fuentes: [repositorio original contrastado](https://github.com/k-bosko/purchase_prediction), [umbral y riesgo de sobreajuste](https://scikit-learn.org/stable/modules/classification_threshold.html).
"""
(OUT / "INFORME.md").write_text(report, encoding="utf-8")

# Execute only new presentation cells: existing research outputs are reproducible inputs.
section = nbformat.v4.new_notebook(
    cells=[
        nbformat.v4.new_markdown_cell("""## 9. ¿Podemos superar 60 % de precisión y recall a la vez?

**Requisito del usuario:** ambas >60 % con un mismo umbral, manteniendo todas las visitas de validación. El resultado a umbral 50 % era solo un punto operativo.

Revisamos origen, señales recientes, cadencia individual, fases temporales, identidad de clientes conocidos, dos búsquedas nuevas de 25 pruebas y mezclas simples. Elegimos con días 297–512 y comprobamos en 513–620, periodo previamente observado. No se usa el benchmark 621–730.

Los máximos por barrido de umbral de la tabla son diagnósticos optimistas. La segunda tabla muestra la decisión con el umbral congelado. El [informe de investigación](../outputs/research_6060/INFORME.md) documenta supuestos y límites."""),
        nbformat.v4.new_code_cell("""from pathlib import Path
import json
import pandas as pd
from IPython.display import Image, Markdown, display
from ferreyros_propension.plotting import style_table

research_root = Path.cwd()
if not (research_root / "outputs").exists():
    research_root = research_root.parent
research = research_root / "outputs/research_6060"
selection_6060 = pd.read_csv(research / "selection.csv")
display(style_table(selection_6060[["candidate", "precision_at_recall60", "recall_at_precision60", "balanced_frontier", "feasible_6060"]]))
summary_6060 = json.loads((research / "summary.json").read_text())
display(Markdown("**Seleccionado antes de la comprobación:** " + summary_6060["winner_selected_first_two_folds"]))
display(style_table(pd.Series(summary_6060["balanced_threshold_chronological_check"])))
display(Image(filename=str(research / "precision_recall_6060.png")))
display(Markdown("**Conclusión:** esta búsqueda no demuestra un límite imposible de superar; muestra si los candidatos probados cumplen el objetivo y qué compromisos ofrecen. No se promociona una mejora solo por ajustar el umbral."))"""),
    ]
)
section = NotebookClient(
    section,
    timeout=120,
    kernel_name="python3",
    resources={"metadata": {"path": str(Path.cwd())}},
).execute()
path = Path("notebooks/02_modelado_resultados.ipynb")
notebook = nbformat.read(path, 4)
start = next(
    (i for i, c in enumerate(notebook.cells) if c.source.startswith("## 9. ¿Podemos")),
    len(notebook.cells),
)
notebook.cells = notebook.cells[:start] + section.cells
nbformat.write(notebook, path)
print(
    json.dumps(
        {
            "winner": winner,
            "threshold": threshold,
            "check": actual,
            "seconds": summary["seconds"],
        },
        indent=2,
    )
)
