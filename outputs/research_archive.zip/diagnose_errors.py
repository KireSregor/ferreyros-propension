"""Controlled frozen/refitted comparison and descriptive false-positive attribution."""

import json
from pathlib import Path

import numpy as np
import pandas as pd
from lightgbm import LGBMClassifier
from sklearn.metrics import confusion_matrix, roc_auc_score
from threadpoolctl import threadpool_limits

from ferreyros_propension.data import load_data
from ferreyros_propension.feature_research import enriched_features

OUT = Path("outputs/refit_lightgbm")


def main():
    configuration = json.loads((OUT / "summary.json").read_text())["selected"]
    threshold = configuration["threshold"]
    raw = load_data("Dataset/compras_data.csv")
    events, x = enriched_features(raw[raw.dia_visita.le(620)])
    x = x.drop(columns="cliente_conocido")
    rows, predictions = [], {}
    for cut in [404, 512]:
        train = events.dia_visita.between(cut - configuration["window"] + 1, cut)
        a, b = x[train].copy(), x.copy()
        for column in a.select_dtypes(include=["object", "string"]).columns:
            dtype = pd.CategoricalDtype(categories=a[column].unique())
            a[column], b[column] = a[column].astype(dtype), b[column].astype(dtype)
        model = LGBMClassifier(
            **configuration["params"], random_state=237, n_jobs=4, verbosity=-1
        )
        model.fit(a, events.loc[train, "incidencia_compra"])
        p = model.predict_proba(b)[:, 1]
        contributions = model.predict(b, pred_contrib=True)
        predictions[cut] = (p, contributions)
        periods = [(405, 512), (513, 620)] if cut == 404 else [(513, 620)]
        for start, end in periods:
            mask = events.dia_visita.between(start, end)
            y = events.loc[mask, "incidencia_compra"]
            tn, fp, fn, tp = confusion_matrix(y, p[mask] >= threshold).ravel()
            rows.append(
                {
                    "training_cut": cut,
                    "period": f"{start}-{end}",
                    "precision": tp / (tp + fp),
                    "recall": tp / (tp + fn),
                    "fpr": fp / (fp + tn),
                    "auc": roc_auc_score(y, p[mask]),
                    "fp": int(fp),
                    "tp": int(tp),
                }
            )
    # Standardize by customer: separate visitor mix from within-customer error changes.
    p, contributions = predictions[404]
    data = events.copy()
    data["period"] = np.where(events.dia_visita.le(512), "before", "after")
    data["false_alarm"] = (p >= threshold).astype(int)
    negatives = data[data.dia_visita.ge(405) & data.incidencia_compra.eq(0)]
    customer = (
        negatives.groupby(["id", "period"])
        .false_alarm.agg(["sum", "count", "mean"])
        .unstack()
    )
    shared = customer.dropna()
    expected = float((shared["mean"]["before"] * shared["count"]["after"]).sum())
    actual = float(shared["sum"]["after"].sum())
    # Segments fixed on training cut, not chosen for strongest validation differences.
    segments = {
        "historical_propensity": pd.cut(
            events.tasa_previa, [-np.inf, 0.1, 0.2, 0.3, 0.5, np.inf]
        ).astype(str),
        "previous_visit_purchase": events.groupby("id")
        .incidencia_compra.shift()
        .fillna(-1)
        .astype(str),
        "recency": pd.cut(
            events.dias_desde_compra, [-np.inf, 7, 30, 60, np.inf]
        ).astype(str),
        "promotions": events[[f"promo_marca_{i}" for i in range(1, 6)]]
        .sum(axis=1)
        .astype(str),
    }
    segment_rows = []
    for name, values in segments.items():
        temp = data.assign(segment=values)
        temp = temp[temp.dia_visita.ge(405) & temp.incidencia_compra.eq(0)]
        for (period, segment), group in temp.groupby(["period", "segment"]):
            segment_rows.append(
                {
                    "variable": name,
                    "segment": segment,
                    "period": period,
                    "n_nonbuyers": len(group),
                    "false_alarm_rate": group.false_alarm.mean(),
                    "false_alarms": int(group.false_alarm.sum()),
                }
            )
    pd.DataFrame(segment_rows).to_csv(OUT / "error_segments.csv", index=False)
    # Contributions describe the model, not causal effects of the predictors.
    masks = [
        events.dia_visita.between(405, 512) & events.incidencia_compra.eq(0),
        events.dia_visita.between(513, 620) & events.incidencia_compra.eq(0),
    ]
    changes = pd.DataFrame(
        {
            "feature": list(x),
            "contribution_before": contributions[masks[0], :-1].mean(axis=0),
            "contribution_after": contributions[masks[1], :-1].mean(axis=0),
        }
    )
    changes["change"] = changes.contribution_after - changes.contribution_before
    changes.sort_values("change", ascending=False).to_csv(
        OUT / "contribution_changes.csv", index=False
    )
    result = {
        "controlled_comparison": rows,
        "customer_standardization": {
            "shared_customers": len(shared),
            "expected_fp_if_customer_rates_unchanged": expected,
            "actual_fp": actual,
        },
        "scope": "Frozen model trained<=404 versus refit<=512, identical later visits. No621+. Descriptive attribution, not causal identification.",
    }
    (OUT / "error_cause.json").write_text(json.dumps(result, indent=2))
    print(json.dumps(result, indent=2))
    print(changes.sort_values("change", ascending=False).head(8).to_string(index=False))


if __name__ == "__main__":
    with threadpool_limits(limits=4):
        main()
