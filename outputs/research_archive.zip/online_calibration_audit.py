"""Evaluate causal daily correction of store-wide prediction errors.

All visits of a day receive the same adjustment learned from earlier days.
This assumes purchase outcomes become available at the end of each day.
Window, shrinkage and decision threshold are selected on days 297–512;
days 513–620 are a previously inspected development check, not a fresh test.
"""

import json
from pathlib import Path
from time import perf_counter

import numpy as np
import pandas as pd
from scipy.special import expit, logit

from audit_6060_round2 import balanced_point
from investigate_6060 import operating_points, score_at

OUT = Path("outputs/online_calibration")


def correct_daily(frame, window, strength, prior_visits):
    """Shrink previous aggregate errors toward no correction, excluding today."""
    frame = frame.sort_values(["dia_visita", "id"]).reset_index(drop=True)
    daily = frame.groupby("dia_visita").agg(
        observed=("y", "sum"), expected=("p", "sum"), visits=("y", "size")
    )
    daily = daily.reindex(range(int(daily.index.min()), int(daily.index.max()) + 1))
    past = daily.rolling(window, min_periods=1).sum().shift(1)
    expected_rate = past.expected / past.visits
    observed_rate = (past.observed + prior_visits * expected_rate) / (
        past.visits + prior_visits
    )
    adjustment = strength * (
        logit(observed_rate.clip(1e-5, 1 - 1e-5))
        - logit(expected_rate.clip(1e-5, 1 - 1e-5))
    )
    frame["p"] = expit(
        logit(frame.p.clip(1e-5, 1 - 1e-5)) + frame.dia_visita.map(adjustment).fillna(0)
    )
    return frame


def main():
    started = perf_counter()
    OUT.mkdir(exist_ok=True)
    base = pd.read_csv("outputs/finalists/catboost_oof.csv")
    dynamic = pd.concat(
        [
            pd.read_csv("outputs/audit_round2/lightgbm_dynamic_selection.csv"),
            pd.read_csv("outputs/audit_round2/winner_check.csv"),
        ],
        ignore_index=True,
    )
    sources = {"catboost": base, "lightgbm_dynamic": dynamic}
    rows = []
    for name, source in sources.items():
        selection = source[source.dia_visita.le(512)]
        for window in [1, 3, 7, 14, 30]:
            for strength in [0, 0.25, 0.5, 1.0]:
                for prior in [50, 200]:
                    predicted = correct_daily(selection, window, strength, prior)
                    balance, threshold = balanced_point(predicted.y, predicted.p)
                    rows.append(
                        {
                            "source": name,
                            "window": window,
                            "strength": strength,
                            "prior_visits": prior,
                            "balance": balance,
                            **score_at(predicted.y, predicted.p, threshold),
                        }
                    )
    pd.DataFrame(rows).to_csv(OUT / "selection.csv", index=False)
    winner = max(rows, key=lambda row: row["balance"])
    source = sources[winner["source"]]
    args = (winner["window"], winner["strength"], winner["prior_visits"])
    predicted = correct_daily(source, *args)
    # Changing today's and future labels must not change today's predictions.
    changed = source.copy()
    changed.loc[changed.dia_visita.ge(513), "y"] = (
        1 - changed.loc[changed.dia_visita.ge(513), "y"]
    )
    altered = correct_daily(changed, *args)
    np.testing.assert_array_equal(
        predicted.loc[predicted.dia_visita.le(513), "p"],
        altered.loc[altered.dia_visita.le(513), "p"],
    )
    check = predicted[predicted.dia_visita.gt(512)]
    check.to_csv(OUT / "check.csv", index=False)
    summary = {
        "selected": winner,
        "check": score_at(check.y, check.p, winner["threshold"]),
        "frontier_diagnostic": operating_points(check.y, check.p),
        "seconds": perf_counter() - started,
        "causality_check": "Current and future labels do not affect predictions.",
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
