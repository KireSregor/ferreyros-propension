"""Fresh LightGBM search prioritizing recall with precision above 51%.

Select on 297–512, freeze threshold, check 513–620 (previously inspected).
No final test is scored. A finite search does not certify no overfitting.
"""

import json
from pathlib import Path
from time import perf_counter

import numpy as np
import optuna
import pandas as pd
from lightgbm import LGBMClassifier
from sklearn.metrics import (
    f1_score,
    precision_recall_curve,
    precision_score,
    recall_score,
)
from threadpoolctl import threadpool_limits

from ferreyros_propension.data import load_data
from ferreyros_propension.feature_research import enriched_features

OUT = Path("outputs/refit_lightgbm")


def scores(y, p, threshold):
    labels = p >= threshold
    return {
        "precision": precision_score(y, labels),
        "recall": recall_score(y, labels),
        "f1": f1_score(y, labels),
        "threshold": float(threshold),
    }


def operating_point(y, p):
    precision, recall, thresholds = precision_recall_curve(y, p)
    # Prefer recall >=55%; penalize unmet constraints rather than claiming success.
    utility = recall[:-1] - 4 * np.maximum(0.515 - precision[:-1], 0)
    index = int(np.argmax(utility))
    return float(utility[index]), float(thresholds[index])


def predict(events, x, params, folds, window):
    frames = []
    for cut, end in folds:
        train = events.dia_visita.le(cut)
        if window:
            train &= events.dia_visita.gt(cut - window)
        valid = events.dia_visita.between(cut + 1, end)
        a, b = x[train].copy(), x[valid].copy()
        for column in a.select_dtypes(include=["object", "string"]).columns:
            dtype = pd.CategoricalDtype(categories=a[column].unique())
            a[column], b[column] = a[column].astype(dtype), b[column].astype(dtype)
        model = LGBMClassifier(**params, random_state=237, n_jobs=4, verbosity=-1)
        model.fit(a, events.loc[train, "incidencia_compra"])
        frame = events.loc[valid, ["id", "dia_visita", "incidencia_compra"]].rename(
            columns={"incidencia_compra": "y"}
        )
        frame["p"] = model.predict_proba(b)[:, 1]
        frames.append(frame)
    return pd.concat(frames, ignore_index=True)


def main():
    started = perf_counter()
    OUT.mkdir(exist_ok=True)
    raw = load_data("Dataset/compras_data.csv")
    events, x = enriched_features(raw[raw.dia_visita.le(620)])
    x = x.drop(columns="cliente_conocido")
    candidates = []
    study = optuna.create_study(
        direction="maximize", sampler=optuna.samplers.TPESampler(seed=237)
    )

    def objective(trial):
        params = {
            "n_estimators": trial.suggest_int("n_estimators", 150, 750, step=100),
            "learning_rate": trial.suggest_float(
                "learning_rate", 0.015, 0.09, log=True
            ),
            "num_leaves": trial.suggest_int("num_leaves", 5, 31),
            "min_child_samples": trial.suggest_int("min_child_samples", 100, 450),
            "reg_lambda": trial.suggest_float("reg_lambda", 2, 150, log=True),
            "reg_alpha": trial.suggest_float("reg_alpha", 0.01, 20, log=True),
            "colsample_bytree": trial.suggest_float("colsample_bytree", 0.5, 1),
        }
        window = trial.suggest_categorical("window", [0, 270, 365])
        frame = predict(events, x, params, [(296, 404), (404, 512)], window)
        utility, threshold = operating_point(frame.y, frame.p)
        candidates.append(
            {
                "trial": trial.number,
                "params": params,
                "window": window,
                "utility": utility,
                **scores(frame.y, frame.p.to_numpy(), threshold),
            }
        )
        print(
            "trial",
            trial.number,
            candidates[-1]["precision"],
            candidates[-1]["recall"],
            flush=True,
        )
        return utility

    study.optimize(objective, n_trials=40)
    selected = max(candidates, key=lambda row: row["utility"])
    check = predict(events, x, selected["params"], [(512, 620)], selected["window"])
    assert len(check) == 8029
    check.to_csv(OUT / "check.csv", index=False)
    (OUT / "selection.json").write_text(json.dumps(candidates, indent=2))
    summary = {
        "selected": selected,
        "check": scores(check.y, check.p.to_numpy(), selected["threshold"]),
        "seconds": perf_counter() - started,
        "scope": "Fresh40trials; selection297-512; previously inspected check513-620; no621+.",
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2))
    print("FINISHED", json.dumps(summary), flush=True)


if __name__ == "__main__":
    optuna.logging.set_verbosity(optuna.logging.WARNING)
    with threadpool_limits(limits=4):
        main()
