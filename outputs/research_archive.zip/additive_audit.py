"""Compare additive and pairwise models to restrict memorization of interactions."""

import json
from pathlib import Path
from time import perf_counter

import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier
from threadpoolctl import threadpool_limits

from audit_6060_round2 import balanced_point, dynamic_features
from ferreyros_propension.data import load_data
from investigate_6060 import operating_points, score_at

OUT = Path("outputs/additive_audit")


def predict_windows(events, features, params, folds):
    predictions = []
    for number, (cut, end) in enumerate(folds):
        train = events.dia_visita.le(cut)
        valid = events.dia_visita.between(cut + 1, end)
        a, b = features[train].copy(), features[valid].copy()
        for column in a.select_dtypes(include=["object", "string"]).columns:
            dtype = pd.CategoricalDtype(categories=a[column].unique())
            a[column] = a[column].astype(dtype)
            b[column] = b[column].astype(dtype)
        model = HistGradientBoostingClassifier(
            **params,
            learning_rate=0.05,
            min_samples_leaf=150,
            early_stopping=False,
            random_state=42,
        )
        model.fit(a, events.loc[train, "incidencia_compra"])
        frame = events.loc[valid, ["id", "dia_visita", "incidencia_compra"]].rename(
            columns={"incidencia_compra": "y"}
        )
        frame["p"] = model.predict_proba(b)[:, 1]
        frame["fold"] = number
        predictions.append(frame)
    return pd.concat(predictions, ignore_index=True)


def main():
    started = perf_counter()
    OUT.mkdir(exist_ok=True)
    raw = load_data("Dataset/compras_data.csv")
    events, features = dynamic_features(raw[raw.dia_visita.le(620)])
    features = features.drop(columns="cliente_conocido")
    spaces = {"core": features.iloc[:, :46], "full": features}
    records = []
    for space, frame in spaces.items():
        for interactions in ["no_interactions", "pairwise"]:
            for regularization in [10, 100]:
                for iterations in [150, 450]:
                    name = f"{space}_{interactions}_{regularization}_{iterations}"
                    params = {
                        "interaction_cst": interactions,
                        "l2_regularization": regularization,
                        "max_iter": iterations,
                        "max_leaf_nodes": 7,
                    }
                    predicted = predict_windows(
                        events, frame, params, [(296, 404), (404, 512)]
                    )
                    balance, threshold = balanced_point(predicted.y, predicted.p)
                    scores = [
                        score_at(part.y, part.p, threshold)
                        for _, part in predicted.groupby("fold")
                    ]
                    stability = min(
                        min(row["precision"], row["recall"]) for row in scores
                    )
                    records.append(
                        {
                            "name": name,
                            "space": space,
                            "params": params,
                            "stability": stability,
                            "balance": balance,
                            **score_at(predicted.y, predicted.p, threshold),
                        }
                    )
                    predicted.to_csv(OUT / f"{name}_selection.csv", index=False)
                    print(name, round(stability, 4), flush=True)
    (OUT / "selection.json").write_text(json.dumps(records, indent=2))
    selected = max(records, key=lambda row: row["stability"])
    check = predict_windows(
        events, spaces[selected["space"]], selected["params"], [(512, 620)]
    )
    assert len(check) == 8029 and not check.duplicated(["id", "dia_visita"]).any()
    check.to_csv(OUT / "check.csv", index=False)
    summary = {
        "selected": selected,
        "check": score_at(check.y, check.p, selected["threshold"]),
        "frontier": operating_points(check.y, check.p),
        "seconds": perf_counter() - started,
        "scope": "Selection297-512; previously inspected check513-620; no621+.",
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2))
    print("FINISHED", json.dumps(summary), flush=True)


if __name__ == "__main__":
    with threadpool_limits(limits=4):
        main()
