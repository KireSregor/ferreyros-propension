"""Segunda auditoría: dinámica de tienda, capacidad y ventanas recientes.

Selección exclusivamente en 297–512; una comprobación del ganador en 513–620.
No presupone que exista un umbral que logre 60/60 ni altera la población.
"""

import json
import os
from pathlib import Path
from time import perf_counter

os.environ["MLFLOW_DISABLE_AGENT_HINT"] = "1"
import numpy as np
import optuna
import pandas as pd
from catboost import CatBoostClassifier
from lightgbm import LGBMClassifier
from sklearn.metrics import precision_recall_curve
from threadpoolctl import threadpool_limits

from ferreyros_propension.data import load_data
from ferreyros_propension.feature_research import enriched_features
from investigate_6060 import operating_points, score_at

OUT = Path("outputs/audit_round2")
FOLDS = [(296, 404), (404, 512)]


def dynamic_features(raw):
    events, x = enriched_features(raw)
    daily = events.groupby("dia_visita").incidencia_compra.agg(["sum", "count"])
    daily = daily.reindex(range(1, int(events.dia_visita.max()) + 1), fill_value=0)
    for window in [1, 3, 7, 14, 30, 60]:
        past = daily.rolling(window, min_periods=1).sum().shift()
        x[f"tienda_tasa_previa_{window}"] = events.dia_visita.map(
            (past["sum"] + 1) / (past["count"] + 4)
        )
        x[f"tienda_visitas_previas_{window}"] = events.dia_visita.map(past["count"])
    x["tienda_cambio_tasa"] = x.tienda_tasa_previa_7 - x.tienda_tasa_previa_30
    x["tasa_personal_vs_tienda"] = events.tasa_previa - x.tienda_tasa_previa_30
    group = events.groupby("id", sort=False)
    x["marca_visita_anterior"] = (
        group.id_marca.shift().fillna(-1).astype(int).astype(str)
    )
    x["cantidad_visita_anterior"] = group.cantidad.shift()
    # Lifetime propensity can be slow to react to a recent behavioural change.
    x["cambio_tasa_personal"] = events.tasa_30 - events.tasa_previa
    x["cambio_tasa_personal_90"] = events.tasa_30 - events.tasa_90
    for brand in range(1, 6):
        previous = group[f"precio_marca_{brand}"].shift()
        x[f"cambio_precio_{brand}"] = events[f"precio_marca_{brand}"] / previous - 1
    return events, x


def balanced_point(y, p):
    precision, recall, threshold = precision_recall_curve(y, p)
    values = np.minimum(precision[:-1], recall[:-1])
    i = int(np.argmax(values))
    return float(values[i]), float(threshold[i])


def predict(family, params, window, events, x, folds, train_report=False):
    predictions, diagnostics = [], []
    for fold, (cut, end) in enumerate(folds):
        mask = events.dia_visita.le(cut)
        if window:
            mask &= events.dia_visita.gt(cut - window)
        validation = events.dia_visita.between(cut + 1, end)
        a, b = x.loc[mask].copy(), x.loc[validation].copy()
        cats = list(a.select_dtypes(include=["object", "string"]).columns)
        if family == "lightgbm":
            for col in cats:
                dtype = pd.CategoricalDtype(categories=a[col].unique())
                a[col], b[col] = a[col].astype(dtype), b[col].astype(dtype)
            model = LGBMClassifier(**params, random_state=42, n_jobs=4, verbosity=-1)
        else:
            model = CatBoostClassifier(
                **params,
                random_seed=42,
                thread_count=4,
                cat_features=cats,
                verbose=False,
                allow_writing_files=False,
            )
        model.fit(a, events.loc[mask, "incidencia_compra"])
        p = model.predict_proba(b)[:, 1]
        frame = events.loc[
            validation, ["id", "dia_visita", "incidencia_compra"]
        ].rename(columns={"incidencia_compra": "y"})
        frame["p"] = p
        frame["fold"] = fold
        predictions.append(frame)
        if train_report:
            train_p = model.predict_proba(a)[:, 1]
            diagnostics.append(
                {
                    "cut": cut,
                    "n_train": int(mask.sum()),
                    **operating_points(events.loc[mask, "incidencia_compra"], train_p),
                }
            )
    return pd.concat(predictions, ignore_index=True), diagnostics


def main():
    started = perf_counter()
    OUT.mkdir(parents=True, exist_ok=True)
    raw = load_data("Dataset/compras_data.csv")
    raw = raw.loc[raw.dia_visita.le(620)].copy()
    events, x = dynamic_features(raw)
    _, early = dynamic_features(raw.loc[raw.dia_visita.le(296)])
    pd.testing.assert_frame_equal(
        x[events.dia_visita.le(296)].reset_index(drop=True), early
    )
    # Even all outcomes of a day must be unavailable to all visits that day.
    perturbed = raw.copy()
    perturbed.loc[
        perturbed.dia_visita.eq(296), ["incidencia_compra", "id_marca", "cantidad"]
    ] = [1, 5, 99]
    _, changed = dynamic_features(perturbed)
    pd.testing.assert_frame_equal(
        x[events.dia_visita.le(296)], changed[events.dia_visita.le(296)]
    )
    rows = []
    candidates = {}

    def register(name, family, params, window, frame, elapsed, columns):
        frontier, threshold = balanced_point(frame.y, frame.p)
        row = {
            "candidate": name,
            "family": family,
            "window": window,
            "seconds": elapsed,
            "threshold": threshold,
            **score_at(frame.y, frame.p, threshold),
            **operating_points(frame.y, frame.p),
        }
        rows.append(row)
        candidates[name] = (family, params, window, columns)
        frame.to_csv(OUT / f"{name}_selection.csv", index=False)
        pd.DataFrame(rows).to_csv(OUT / "selection.csv", index=False)
        print(name, "min(P,R)", round(frontier, 4), flush=True)

    # Explicit old vs new feature control with identical CatBoost parameters.
    params = json.loads(Path("outputs/best_params.json").read_text())["catboost"]
    tick = perf_counter()
    frame, _ = predict("catboost", params, 0, events, x, FOLDS)
    register(
        "catboost_dynamic", "catboost", params, 0, frame, perf_counter() - tick, list(x)
    )
    study = optuna.create_study(
        direction="maximize",
        storage="sqlite:///" + (OUT / "optuna.db").as_posix(),
        study_name="dynamic_lgbm_v1",
        load_if_exists=True,
        sampler=optuna.samplers.TPESampler(seed=73),
    )

    def objective(trial):
        window = trial.suggest_categorical("window", [0, 180, 270, 365])
        keep_id = trial.suggest_categorical("customer_id", [False, True])
        columns = list(x) if keep_id else [c for c in x if c != "cliente_conocido"]
        configuration = {
            "n_estimators": trial.suggest_int("n_estimators", 150, 1200, step=50),
            "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.15, log=True),
            "num_leaves": trial.suggest_int("num_leaves", 5, 96),
            "min_child_samples": trial.suggest_int("min_child_samples", 10, 300),
            "reg_lambda": trial.suggest_float("reg_lambda", 0.01, 200, log=True),
            "reg_alpha": trial.suggest_float("reg_alpha", 0.0001, 20, log=True),
            "colsample_bytree": trial.suggest_float("colsample_bytree", 0.5, 1),
            "subsample": trial.suggest_float("subsample", 0.6, 1),
            "subsample_freq": 1,
            "scale_pos_weight": trial.suggest_categorical(
                "scale_pos_weight", [1.0, 1.5, 2.0, 3.0]
            ),
        }
        frame, _ = predict("lightgbm", configuration, window, events, x[columns], FOLDS)
        frontier, threshold = balanced_point(frame.y, frame.p)
        trial.set_user_attr("configuration", configuration)
        trial.set_user_attr("columns", columns)
        trial.set_user_attr("frontier", operating_points(frame.y, frame.p))
        if trial.number % 10 == 0:
            print("LGB trial", trial.number, "min(P,R)", round(frontier, 4), flush=True)
        return frontier

    tick = perf_counter()
    complete = sum(t.state == optuna.trial.TrialState.COMPLETE for t in study.trials)
    study.optimize(objective, n_trials=max(0, 60 - complete))
    best = study.best_trial
    configuration = best.user_attrs["configuration"]
    columns = best.user_attrs["columns"]
    window = best.params["window"]
    frame, diagnostics = predict(
        "lightgbm", configuration, window, events, x[columns], FOLDS, True
    )
    pd.DataFrame(diagnostics).to_csv(OUT / "lightgbm_dynamic_train.csv", index=False)
    register(
        "lightgbm_dynamic",
        "lightgbm",
        configuration,
        window,
        frame,
        perf_counter() - tick,
        columns,
    )
    study.trials_dataframe().to_csv(OUT / "trials.csv", index=False)
    # Test capacity and recency without another large search.
    for depth, iterations, window in [
        (4, 900, 0),
        (6, 900, 180),
        (8, 600, 0),
        (5, 700, 270),
    ]:
        candidate = {
            "depth": depth,
            "iterations": iterations,
            "learning_rate": 0.03,
            "l2_leaf_reg": 15,
        }
        tick = perf_counter()
        frame, diagnostics = predict(
            "catboost", candidate, window, events, x, FOLDS, True
        )
        name = f"catboost_depth{depth}_window{window}"
        pd.DataFrame(diagnostics).to_csv(OUT / f"{name}_train.csv", index=False)
        register(
            name, "catboost", candidate, window, frame, perf_counter() - tick, list(x)
        )
    ranking = pd.DataFrame(rows).sort_values("balanced_frontier", ascending=False)
    winner = ranking.iloc[0].candidate
    family, params, window, columns = candidates[winner]
    threshold = float(ranking.iloc[0].threshold)
    frame, diagnostics = predict(
        family, params, window, events, x[columns], [(512, 620)], True
    )
    frame.to_csv(OUT / "winner_check.csv", index=False)
    summary = {
        "winner": winner,
        "threshold": threshold,
        "selection": ranking.iloc[0].to_dict(),
        "check": score_at(frame.y, frame.p, threshold),
        "check_frontier_diagnostic": operating_points(frame.y, frame.p),
        "features": columns,
        "params": params,
        "seconds": perf_counter() - started,
        "invariance": "prefix and all-current-day outcomes passed",
        "caveat": "Selection297-512; previously seen check513-620; no scoring621-730.",
    }
    (OUT / "summary.json").write_text(json.dumps(summary, indent=2))
    print("FINISHED", json.dumps(summary), flush=True)


if __name__ == "__main__":
    optuna.logging.set_verbosity(optuna.logging.WARNING)
    with threadpool_limits(limits=4):
        main()
