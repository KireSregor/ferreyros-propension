"""Chronological stacking: fit 297–404, select 405–512, check 513–620.

The check window has been inspected previously; it is not an independent test.
Only saved out-of-fold predictions enter the meta-model.
"""

import json
from pathlib import Path
from time import perf_counter

import numpy as np
import pandas as pd
from scipy.special import logit
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from audit_6060_round2 import balanced_point
from investigate_6060 import operating_points, score_at


def main():
    started = perf_counter()
    output = Path("outputs/stacking_55")
    output.mkdir(exist_ok=True)
    frame = pd.read_csv("outputs/tables/oof.csv")[["id", "dia_visita", "y", "baseline"]]
    for name in ["catboost", "xgboost"]:
        predictions = pd.read_csv(f"outputs/finalists/{name}_oof.csv")
        frame = frame.merge(
            predictions[["id", "dia_visita", "p"]].rename(columns={"p": name}),
            on=["id", "dia_visita"],
            validate="one_to_one",
        )
    dynamic = pd.concat(
        [
            pd.read_csv("outputs/audit_round2/lightgbm_dynamic_selection.csv"),
            pd.read_csv("outputs/audit_round2/winner_check.csv"),
        ]
    )
    neural = pd.concat(
        [
            pd.read_csv(f"outputs/tabm_extended/full_regularized_s42_cut{cut}.csv")
            for cut in [296, 404, 512]
        ]
    )
    for name, predictions in [("dynamic", dynamic), ("neural", neural)]:
        frame = frame.merge(
            predictions[["id", "dia_visita", "p"]].rename(columns={"p": name}),
            on=["id", "dia_visita"],
            validate="one_to_one",
        )
    assert len(frame) == 24802 and frame.dia_visita.max() == 620
    columns = ["baseline", "catboost", "xgboost", "dynamic", "neural"]
    x = logit(frame[columns].clip(1e-6, 1 - 1e-6))
    train = frame.dia_visita.le(404)
    valid = frame.dia_visita.between(405, 512)
    check = frame.dia_visita.gt(512)
    records = []
    for regularization in [0.0001, 0.001, 0.01, 0.1, 1, 10]:
        model = make_pipeline(
            StandardScaler(), LogisticRegression(C=regularization, max_iter=2000)
        )
        model.fit(x[train], frame.loc[train, "y"])
        p = model.predict_proba(x[valid])[:, 1]
        balance, threshold = balanced_point(frame.loc[valid, "y"], p)
        records.append(
            {
                "C": regularization,
                "balance": balance,
                **score_at(frame.loc[valid, "y"], p, threshold),
            }
        )
    selected = max(records, key=lambda row: row["balance"])
    model = make_pipeline(
        StandardScaler(), LogisticRegression(C=selected["C"], max_iter=2000)
    )
    model.fit(x[~check], frame.loc[~check, "y"])
    p = model.predict_proba(x[check])[:, 1]
    assert np.isfinite(p).all()
    result = frame.loc[check, ["id", "dia_visita", "y"]].copy()
    result["p"] = p
    result.to_csv(output / "check.csv", index=False)
    pd.DataFrame(records).to_csv(output / "selection.csv", index=False)
    summary = {
        "selected": selected,
        "check": score_at(result.y, p, selected["threshold"]),
        "frontier": operating_points(result.y, p),
        "seconds": perf_counter() - started,
    }
    (output / "summary.json").write_text(json.dumps(summary, indent=2))
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
