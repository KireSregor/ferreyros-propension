"""Publish measured neural experiments without retraining or scoring the test."""

import json
from pathlib import Path

import matplotlib.pyplot as plt
import nbformat
import pandas as pd
from matplotlib.ticker import PercentFormatter
from nbclient import NotebookClient
from sklearn.metrics import precision_recall_curve

from audit_6060_round2 import balanced_point
from investigate_6060 import score_at

OUT = Path("outputs/tabm_comparison")
EXPERIMENTS = {
    "LightGBM + historial ampliado": "audit_round2",
    "TabM + semillas/mezclas": "tabm_gpu",
    "TabM: variables y representaciones": "tabm_extended",
    "Corrección con días anteriores": "online_calibration",
}


def main():
    OUT.mkdir(exist_ok=True)
    baseline = pd.read_csv("outputs/tables/oof.csv")
    baseline["p"] = baseline["baseline"]
    selection = baseline[baseline.dia_visita.le(512)]
    balance, threshold = balanced_point(selection.y, selection.p)
    baseline = baseline[baseline.dia_visita.gt(512)]
    baseline_score = score_at(baseline.y, baseline.p, threshold)
    baseline.to_csv(OUT / "baseline_check.csv", index=False)
    rows = [
        {
            "Experimento": "Referencia: tasa histórica",
            "Precisión": baseline_score["precision"],
            "Recall": baseline_score["recall"],
            "F1": baseline_score["f1"],
            "Umbral fijado": threshold,
            "Min(P,R) selección": balance,
            "Minutos de ejecución": float("nan"),
        }
    ]
    summaries = {}
    for label, directory in EXPERIMENTS.items():
        folder = Path("outputs") / directory
        summary = json.loads((folder / "summary.json").read_text())
        summaries[label] = summary
        selection = summary.get("selected", summary.get("selection"))
        rows.append(
            {
                "Experimento": label,
                "Precisión": summary["check"]["precision"],
                "Recall": summary["check"]["recall"],
                "F1": summary["check"]["f1"],
                "Umbral fijado": summary["check"]["threshold"],
                "Min(P,R) selección": min(selection["precision"], selection["recall"]),
                "Minutos de ejecución": summary["seconds"] / 60,
            }
        )
    results = pd.DataFrame(rows)
    if ((results["Precisión"] > 0.6) & (results["Recall"] > 0.6)).any():
        raise RuntimeError(
            "A candidate met the target: update the interpretation before publishing."
        )
    results.to_csv(OUT / "comparison.csv", index=False)
    metadata = []
    for directory in ["tabm_gpu", "tabm_extended"]:
        for path in (Path("outputs") / directory).glob("*_s*_cut*.json"):
            metadata.append(json.loads(path.read_text()))
    training = pd.DataFrame(metadata)
    training.to_csv(OUT / "training_times.csv", index=False)

    plt.rcParams.update(
        {"font.size": 10, "axes.spines.top": False, "axes.spines.right": False}
    )
    figure, axis = plt.subplots(figsize=(9, 5.8))
    precision, recall, _ = precision_recall_curve(baseline.y, baseline.p)
    axis.plot(
        recall,
        precision,
        color="#89939b",
        linestyle="--",
        label="Referencia: tasa histórica",
    )
    colors = ["#051c2c", "#2251ff", "#00a1a8", "#8b6bb1"]
    for (label, directory), color in zip(EXPERIMENTS.items(), colors):
        filename = "winner_check.csv" if directory == "audit_round2" else "check.csv"
        frame = pd.read_csv(Path("outputs") / directory / filename)
        precision, recall, _ = precision_recall_curve(frame.y, frame.p)
        axis.plot(recall, precision, label=label, color=color, linewidth=1.8)
        point = summaries[label]["check"]
        axis.scatter(point["recall"], point["precision"], color=color, s=40, zorder=5)
    axis.fill_between([0.6, 1], 0.6, 1, color="#ccebe4", alpha=0.6)
    axis.text(0.71, 0.85, "Objetivo: ambas >60%", color="#136352")
    axis.axhline(0.6, color="#7b8790", linewidth=0.8, linestyle="--")
    axis.axvline(0.6, color="#7b8790", linewidth=0.8, linestyle="--")
    axis.set(
        xlim=(0, 1),
        ylim=(0, 1),
        xlabel="Recall: compras detectadas / compras reales",
        ylabel="Precisión: aciertos / visitas señaladas",
    )
    axis.xaxis.set_major_formatter(PercentFormatter(1))
    axis.yaxis.set_major_formatter(PercentFormatter(1))
    axis.set_title(
        "Las nuevas variantes todavía no alcanzan la zona 60/60",
        loc="left",
        fontweight="bold",
        pad=18,
    )
    axis.legend(loc="lower left", frameon=False, fontsize=9)
    figure.text(
        0.12,
        0.01,
        "Días 513–620 · todas las visitas · puntos: umbrales fijados en 297–512.\nCurvas: diagnóstico de umbrales; este periodo ya se había inspeccionado.",
        fontsize=8,
        color="#596b78",
    )
    figure.tight_layout(rect=(0, 0.06, 1, 1))
    figure.savefig(OUT / "precision_recall.png", dpi=160)
    plt.close(figure)

    table = [
        "| Experimento | Precisión | Recall | F1 | Tiempo |",
        "|---|---:|---:|---:|---:|",
    ]
    for row in rows:
        elapsed = row["Minutos de ejecución"]
        elapsed_text = "—" if pd.isna(elapsed) else f"{elapsed:.2f} min"
        table.append(
            f"| {row['Experimento']} | {row['Precisión']:.1%} | {row['Recall']:.1%} | {row['F1']:.3f} | {elapsed_text} |"
        )
    report = (
        """# Redes tabulares y ensamblados: resultado medido

**No se alcanzó precisión >60% y recall >60% simultáneamente.** La búsqueda amplía lo probado, pero no demuestra que ese resultado sea imposible con otros modelos o datos.

## Comparación con umbrales congelados

Todas las filas evalúan las mismas visitas de los días 513–620. Cada variante y su umbral se eligen en 297–512. Las diferencias reflejan tanto el modelo como su umbral elegido; no son un efecto puro de cambiar de algoritmo.

"""
        + "\n".join(table)
        + f"""

Los tiempos son los de cada experimento; las dos búsquedas TabM se solaparon y no deben sumarse como tiempo de espera. No incluyen descargar dependencias. La corrección diaria reutiliza predicciones y su tiempo no incluye entrenar el modelo base.

## Qué se amplió

- TabM oficial, tres arquitecturas, tres semillas para la arquitectura seleccionada y mezclas con CatBoost de pesos 25/50/75%.
- Seis variantes adicionales: 46 variables originales frente a 97 ampliadas, menor tasa de aprendizaje, mayor dropout y embeddings numéricos por tramos.
- Límite de 1.000 épocas por ajuste; paciencia de 50 épocas y mínimo de 100 antes de parar. La época se selecciona en los últimos 54 días del entrenamiento. Después se reajusta en todo ese entrenamiento durante la cantidad seleccionada.
- Corrección causal de errores agregados de tienda: 80 configuraciones, incluidas referencias sin corrección. Solo se utilizan resultados de días anteriores.

Se completaron **{len(training)} combinaciones de configuración, semilla y ventana** de TabM, cada una con entrenamiento interno y reajuste. Épocas internas ejecutadas: {int(training.epochs_run.min())}–{int(training.epochs_run.max())}; épocas seleccionadas: {int(training.selected_epoch.min())}–{int(training.selected_epoch.max())}. Las curvas y tiempos individuales están en `training_times.csv` y en los CSV `*_learning.csv` de cada experimento. Aumentar el límite no obliga a entrenar hasta él cuando empeora la validación.

## Cómo interpretar la evidencia

Las curvas PR recorren todos los umbrales de cada predicción guardada. Si una curva no entra en la zona objetivo, cambiar solamente el umbral de ese modelo no logra 60/60 en esa muestra. Esto **no es una demostración sobre todos los modelos posibles**.

Los días 513–620 ya se habían observado en investigaciones previas: esta comprobación no es un test independiente. Los días 621–730 no se usan para ajustar ni evaluar esta ampliación. Las búsquedas reiteradas sobre validación también pueden sobreajustarla; un resultado final requeriría una evaluación independiente.

No se reemplaza `outputs/model.joblib` ni se publica un nuevo modelo como exitoso. Queda pendiente cumplir el objetivo solicitado o acordar, con evidencia de negocio, otro criterio.

## Fuentes y reproducción

- [TabM oficial](https://github.com/yandex-research/tabm): red tabular con ensamblado eficiente. Se respeta la pérdida por componente y el promedio de probabilidades en inferencia.
- [TabM, ICLR 2025](https://arxiv.org/abs/2410.24210): arquitectura y evaluación; no garantiza una mejora en esta base.
- [Solución de segundo puesto en Kaggle](https://www.kaggle.com/competitions/playground-series-s6e1/writeups/2nd-place-nns-sometimes-work-better-than-gbms): uso de redes, nuevas variables y ensamblados. Sus métricas pertenecen a otro problema y no son una meta transferible.

Dependencias opcionales: `requirements-neural.txt`, después del entorno base. Scripts: `tabm_gpu_audit.py`, `tabm_extended_audit.py`, `online_calibration_audit.py`. Cada búsqueda guarda configuración, predicciones, curvas internas y huellas de código/datos. Los archivos existentes no se reutilizan si cambian las huellas.

Para repetir con la versión actual sin mezclar cachés históricos: `python tabm_gpu_audit.py --output-dir outputs/tabm_gpu_repeat` y `python tabm_extended_audit.py --output-dir outputs/tabm_extended_repeat`. El argumento de carpeta y la representación por tramos se añadieron durante esta investigación; las huellas originales se conservan y una repetición usa una carpeta nueva.

`python consolidate_neural.py` reconstruye esta comparación y la sección 11 del notebook desde resultados guardados, sin reentrenar ni evaluar el test.
"""
    )
    (OUT / "INFORME.md").write_text(report, encoding="utf-8")
    section = nbformat.v4.new_notebook(
        cells=[
            nbformat.v4.new_markdown_cell("""## 11. Más capacidad y redes tabulares: ¿mejoran la detección?

**Objetivo:** precisión y recall superiores al 60% simultáneamente. Comparamos TabM, ensamblados, menos variables y corrección con días anteriores. Máximo: 1.000 épocas, con parada interna temporal.

**Nivel: visita. Periodo: días 513–620, previamente inspeccionado.** Los umbrales se fijaron con 297–512. No se evaluó 621–730 en esta ampliación.

Los puntos muestran la decisión fijada; las curvas permiten ver si otro umbral alcanzaría la zona objetivo. [Método, tiempos y limitaciones](../outputs/tabm_comparison/INFORME.md)."""),
            nbformat.v4.new_code_cell("""from pathlib import Path
import pandas as pd
from IPython.display import Image, display
from ferreyros_propension.plotting import style_table

comparison_root = Path.cwd()
if not (comparison_root / "outputs").exists():
    comparison_root = comparison_root.parent
comparison_folder = comparison_root / "outputs/tabm_comparison"
neural_results = pd.read_csv(comparison_folder / "comparison.csv")
neural_table = neural_results.set_index("Experimento")[["Precisión", "Recall", "F1", "Minutos de ejecución"]]
display(style_table(neural_table.style.format({"Precisión": "{:.1%}", "Recall": "{:.1%}", "F1": "{:.3f}", "Minutos de ejecución": "{:.2f}"}, na_rep="—")))
display(Image(filename=str(comparison_folder / "precision_recall.png")))"""),
            nbformat.v4.new_markdown_cell(
                "**Conclusión:** ninguna de estas variantes satisface todavía el 60/60. Más capacidad y entrenamiento no garantizan mejor generalización. Esto no demuestra que sea imposible; el objetivo continúa pendiente."
            ),
        ]
    )
    section = NotebookClient(
        section,
        timeout=120,
        kernel_name="python3",
        resources={"metadata": {"path": str(Path.cwd())}},
    ).execute()
    path = Path("notebooks/02_modelado_resultados.ipynb")
    notebook = nbformat.read(path, 4)
    start = next(
        (
            i
            for i, cell in enumerate(notebook.cells)
            if cell.source.startswith("## 11. Más capacidad")
        ),
        len(notebook.cells),
    )
    notebook.cells = notebook.cells[:start] + section.cells
    nbformat.write(notebook, path)
    print(results.to_string(index=False))


if __name__ == "__main__":
    main()
